<?php
// ================================================
// SPAW PHP WYSIWYG editor control
// ================================================
// Hebrew language file
// ================================================
// Developed: Alan Mendelevich, alan@solmetra.lt
// Original Translation to Hebrew (v.1.0): Yaron Gonen (lord_gino@yahoo.com)
// Additional Translation to Hebrew (v.1.1): Boris Aranovich (beer_nomaed@hotmail.com)
// Copyright: Solmetra (c)2003 All rights reserved.
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.1.1, 2005-03-20
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// text direction for the language
$spaw_lang_direction = 'rtl';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'Ч’Ч–Ч•ЧЁ'
  ),
  'copy' => array(
    'title' => 'Ч”ЧўЧЄЧ§'
  ),
  'paste' => array(
    'title' => 'Ч”Ч“Ч‘Ч§'
  ),
  'undo' => array(
    'title' => 'Ч‘Ч