<?php 
// ================================================
// SPAW File Manager plugin
// ================================================
// English language file
// ================================================
// Developed: Saulius Okunevicius, saulius@solmetra.com
// Copyright: Solmetra (c)2006 All rights reserved.
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.1.0, 2006-11-20
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'iso-8859-1';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'spawfm' => array(
    'title' => 'SPAW Manager SouborЕЇ',
    'error_reading_dir' => 'Chyba: Nemohu naДЌГ­st obsah adresГЎЕ™e.',
    'error_upload_forbidden' => 'Chyba: upload souboru nenГ­ v tomto adresГЎЕ™i povolen.',
    'error_upload_file_too_big' => 'Upload se nezdaЕ™il: soubor je pЕ™Г­liЕЎ velkГЅ.',
    'error_upload_failed' => 'Upload souboru se nazdaЕ™il.',
    'error_upload_file_incomplete' => 'UploadovanГЅ soubor nenГ­ kompletnГ­, zkuste to znovu.',
    'error_bad_filetype' => 'Chyba: soubory tohoto typu nejsou povoleny.',
    'error_max_filesize' => 'Max. pЕ™Г­pustnГЎ velikost uploudovanГ©ho souboru:',
    'error_delete_forbidden' => 'Chyba: mazГЎnГ­ souborЕЇ v adresГЎЕ™i nenГ­ povoleno.',
    'confirm_delete' => 'Jste si opravdu jist, Еѕe chcete vymazat soubor "[*file*]"?',
    'error_delete_failed' => 'Chyba: soubor nemЕЇЕѕe bГЅt smazГЎn. NemГЎte k tГ©to operaci oprГЎvnД›nГ­.',
    'error_no_directory_available' => 'Nenalezeny ЕѕГЎdnГ© adresГЎЕ™e.',
    'download_file' => '[download file]',
    'error_chmod_uploaded_file' => 'NahrГЎnГ­ souboru se zdaЕ™ilo, ale zmД›na atributЕЇ souboru nebyla ГєspД›ЕЎnГЎ.',
    'error_img_width_max' => 'MaxiГЎlnГ­ povolenГЎ ЕЎГ­Е™ka obrГЎzku: [*MAXWIDTH*]px',
    'error_img_height_max' => 'MaxiГЎlnГ­ povolenГЎ vГЅЕЎka obrГЎzku: [*MAXHEIGHT*]px',
    'rename_text' => 'Zadejte novГ© jmГ©no pro soubor "[*FILE*]":',
    'error_rename_file_missing' => 'PЕ™ejmenovГЎnГ­ se nezdaЕ™ilo - soubor nenalezen.',
    'error_rename_directories_forbidden' => 'Chyba: pЕ™ejmenovГЎnГ­ tohoto adresГЎЕ™e nenГ­ povoleno.',
    'error_rename_forbidden' => 'Chyba: v tomto adresГЎЕ™i nenГ­ povoleno pЕ™ejmenovГЎvat soubory.',
    'error_rename_file_exists' => 'Chyba: "[*FILE*]" jiЕѕ existuje.',
    'error_rename_failed' => 'Chyba: pЕ™ejmenovГЎnГ­ se nezdaЕ™ilo. NemГЎte potЕ™ebnГЎ prГЎva.',
    'error_rename_extension_changed' => 'Chyba: nenГ­ povoleno mД›nit pЕ™Г­ponu souborЕЇ!',
    'newdirectory_text' => 'Zadejte jmГ©no adresГЎЕ™e:',
    'error_create_directories_forbidden' => 'Chyba: vytvГЎЕ™enГ­ adresГЎЕ™ЕЇ je zakГЎzГЎno',
    'error_create_directories_name_used' => 'Tento nГЎzev byl jiЕѕ pouЕѕit, zkuste prosГ­m jinГЅ.',
    'error_create_directories_failed' => 'Chyba: adresГЎЕ™ nemohl bГЅt vytvoЕ™en. NemГЎte potЕ™ebnГЎ prГЎva.',
    'error_create_directories_name_invalid' => 'Tyto znaky nesmГ­ bГЅt pouЕѕity v nГЎzvu adresГЎЕ™e: / \\ : * ? " < > |',
    'confirmdeletedir_text' => 'Jste si jist, Еѕe opravdu chcete smazat adresГЎЕ™ "[*DIR*]"?',
    'error_delete_subdirectories_forbidden' => 'SmazГЎnГ­ adresГЎЕ™e nenГ­ povoleno.',
    'error_delete_subdirectories_failed' => 'AdresГЎЕ™ nemohl bГЅt smazГЎn. NemГЎte potЕ™ebnГЎ prГЎva.',
    'error_delete_subdirectories_not_empty' => 'AdresГЎЕ™ nenГ­ prГЎzdnГЅ.',
  ),
  'buttons' => array(
    'ok'        => '  OK  ',
    'cancel'    => 'ZruЕЎit',
    'view_list' => 'ZobrazenГ­: seznam',
    'view_details' => 'ZobrazenГ­: detaily',
    'view_thumbs' => 'ZobrazenГ­: nГЎhledy',
    'rename'    => 'PЕ™ejmenovat...',
    'delete'    => 'Vymazat',
    'go_up'     => 'O ГєroveЕ€ vГЅЕЎ',
    'upload'    =>  'NahrГЎt',
    'create_directory'  =>  'VytvoЕ™it novГЅ adresГЎЕ™...',
  ),
  'file_details' => array(
    'name'  =>  'JmГ©no',
    'type'  =>  'Typ',
    'size'  =>  'Velikost',
    'date'  =>  'Datum zmД›ny',
    'filetype_suffix'  =>  'soubor',
    'img_dimensions'  =>  'RozmД›ry',
    'file_folder'  =>  'SloЕѕka souborЕЇ',
  ),
  'filetypes' => array(
    'any'       => 'VЕЎechny soubory (*.*)',
    'images'    => 'ObrГЎzky',
    'flash'     => 'Flash',
    'documents' => 'TextovГ© soubory',
    'audio'     => 'ZvukovГ© soubory',
    'video'     => 'Video soubory',
    'archives'  => 'KomprimovanГ© soubory',
    '.jpg'  =>  'JPG obrГЎzek',
    '.jpeg' =>  'JPG obrГЎzek',
    '.gif'  =>  'GIF obrГЎzek',
    '.png'  =>  'PNG obrГЎzek',
    '.swf'  =>  'Flash',
    '.doc'  =>  'Microsoft Word dokument',
    '.xls'  =>  'Microsoft Excel dokument',
    '.pdf'  =>  'PDF dokument',
    '.rtf'  =>  'RTF dokument',
    '.odt'  =>  'OpenDocument Text',
    '.ods'  =>  'OpenDocument Spreadsheet',
    '.sxw'  =>  'OpenOffice.org 1.0 Text Dokument',
    '.sxc'  =>  'OpenOffice.org 1.0 Spreadsheet',
    '.wav'  =>  'WAV audio',
    '.mp3'  =>  'MP3 audio',
    '.ogg'  =>  'Ogg Vorbis audio',
    '.wma'  =>  'Windows audio',
    '.avi'  =>  'AVI video',
    '.mpg'  =>  'MPEG video',
    '.mpeg' =>  'MPEG video',
    '.mov'  =>  'QuickTime video',
    '.wmv'  =>  'Windows video',
    '.zip'  =>  'ZIP archiv',
    '.rar'  =>  'RAR archiv',
    '.gz'   =>  'gzip archiv',
    '.txt'  =>  'TextovГЅ dokument',
    ''  =>  '',
  ),
);
?>
