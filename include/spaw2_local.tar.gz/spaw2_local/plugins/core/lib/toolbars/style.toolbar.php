<?php
$items = array
(
  new SpawTbDropdown("core", "style", "isStyleEnabled", "styleStatusCheck", "styleChange"),
  new SpawTbDropdown("core", "formatBlock", "isStandardFunctionEnabled", "standardFunctionStatusCheck", "standardFunctionChange"),
  new SpawTbImage("core", "separator"),
);
?>
