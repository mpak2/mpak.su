<?php
// ================================================
// SPAW v.2.0
// ================================================
// Lithuanian language file
// ================================================
// Authors: Alan Mendelevich, Martynas Majeris,
//          Saulius Okunevicius, UAB Solmetra
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.2.0
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'IЕЎkirpti'
  ),
  'copy' => array(
    'title' => 'Kopijuoti'
  ),
  'paste' => array(
    'title' => 'Д®terpti'
  ),
  'undo' => array(
    'title' => 'AtЕЎaukti'
  ),
  'redo' => array(
    'title' => 'Pakartoti'
  ),
  'image' => array(
    'title' => 'Greitai ДЇterpti iliustracijД…'
  ),
  'image_prop' => array(
    'title' => 'Iliustracija',
    'ok' => '   GERAI   ',
    'cancel' => 'Nutraukti',
    'source' => 'Е altinis',
    'alt' => 'Alternatyvus tekstas',
    'align' => 'Lygiavimas',
    'left' => 'left (kairД—)',
    'right' => 'right (deЕЎinД—)',
    'top' => 'top (virЕЎus)',
    'middle' => 'middle (vidurys)',
    'bottom' => 'bottom (apaДЌia)',
    'absmiddle' => 'absmiddle (bendras vidurys)',
    'texttop' => 'texttop (teksto virЕЎus)',
    'baseline' => 'baseline (teksto apaДЌia)',
    'width' => 'Plotis',
    'height' => 'AukЕЎtis',
    'border' => 'RД—melio plotis',
    'hspace' => 'Hor. laukelis',
    'vspace' => 'Vert. laukelis',
    'dimensions' => 'IЕЎmatavimai',
    'reset_dimensions' => 'Atstatyti iЕЎmatavimus',
    'title_attr' => 'AntraЕЎtД—',
    'constrain_proportions' => 'iЕЎlaikyti proporcijas',
    'css_class' => 'CSS klasД—', 
    'error' => 'Klaida',
    'error_width_nan' => 'Nurodytas plotis nД—ra skaiДЌius',
    'error_height_nan' => 'Nurodytas aukЕЎtis nД—ra skaiДЌius',
    'error_border_nan' => 'Nurodytas rД—melio plotis nД—ra skaiДЌius',
    'error_hspace_nan' => 'Nurodytas horizontalaus laukelio plotis nД—ra skaiДЌius',
    'error_vspace_nan' => 'Nurodytas vertikalaus laukelio plotis nД—ra skaiДЌius',
  ),
    'flash_prop' => array(
    'title' => 'Flash',
    'ok' => '   GERAI   ',
    'cancel' => 'Nutraukti',
    'source' => 'Е altinis',
    'width' => 'Plotis',
    'height' => 'AukЕЎtis',
    'error' => 'Klaida',
    'error_width_nan' => 'Nurodytas plotis nД—ra skaiДЌius',
    'error_height_nan' => 'Nurodytas aukЕЎtis nД—ra skaiДЌius',
  ),
  'inserthorizontalrule' => array(
    'title' => 'Horizontalus skirtukas'
  ),
  'table_create' => array(
    'title' => 'Sukurti lentelД™'
  ),
  'table_prop' => array(
    'title' => 'LentelД—s parametrai',
    'ok' => '   GERAI   ',
    'cancel' => 'Nutraukti',
    'rows' => 'EiluДЌiЕі',
    'columns' => 'StulpeliЕі',
    'css_class' => 'CSS klasД—', 
    'width' => 'Plotis',
    'height' => 'AukЕЎtis',
    'border' => 'RД—melio plotis',
    'pixels' => 'taЕЎk.',
    'cellpadding' => 'Laukelio atitraukimas (padding)',
    'cellspacing' => 'Tarpas tarp laukeliЕі',
    'bg_color' => 'Fono spalva',
    'background' => 'Fono iliustracija',
    'error' => 'Klaida',
    'error_rows_nan' => 'Nurodytas eiluДЌiЕі kiekis nД—ra skaiДЌius',
    'error_columns_nan' => 'Nurodytas stulpeliЕі kiekis nД—ra skaiДЌius',
    'error_width_nan' => 'Nurodytas plotis nД—ra skaiДЌius',
    'error_height_nan' => 'Nurodytas aukЕЎtis nД—ra skaiДЌius',
    'error_border_nan' => 'Nurodytas rД—melio plotis nД—ra skaiДЌius',
    'error_cellpadding_nan' => 'Nurodytas laukelio atitraukimas nД—ra skaiДЌius',
    'error_cellspacing_nan' => 'Nurodytas tarpas tarp laukeliЕі nД—ra skaiДЌius',
  ),
  'table_cell_prop' => array(
    'title' => 'Laukelio parametrai',
    'horizontal_align' => 'Vertikalus lygiavimas',
    'vertical_align' => 'Horizontalus lygiavimas',
    'width' => 'Plotis',
    'height' => 'AukЕЎtis',
    'css_class' => 'CSS klasД—',
    'no_wrap' => 'Neperkeliamas',
    'bg_color' => 'Fono spalva',
    'background' => 'Fono iliustracija',
    'ok' => '   GERAI   ',
    'cancel' => 'Nutraukti',
    'left' => 'KairД—',
    'center' => 'Centras',
    'right' => 'DeЕЎinД—',
    'top' => 'VirЕЎus',
    'middle' => 'Vidurys',
    'bottom' => 'ApaДЌia',
    'baseline' => 'Teksto apaДЌia',
    'error' => 'Klaida',
    'error_width_nan' => 'Nurodytas plotis nД—ra skaiДЌius',
    'error_height_nan' => 'Nurodytas aukЕЎtis nД—ra skaiДЌius',
  ),
  'table_row_insert' => array(
    'title' => 'Д®terpti eilutД™'
  ),
  'table_column_insert' => array(
    'title' => 'Д®terpti stulpelДЇ'
  ),
  'table_row_delete' => array(
    'title' => 'PaЕЎalinti eilutД™'
  ),
  'table_column_delete' => array(
    'title' => 'PaЕЎalinti stulpelДЇ'
  ),
  'table_cell_merge_right' => array(
    'title' => 'Sujungti laukelius ДЇ deЕЎinД™'
  ),
  'table_cell_merge_down' => array(
    'title' => 'Sujungti laukelius apaДЌion'
  ),
  'table_cell_split_horizontal' => array(
    'title' => 'Padalinti laukelДЇ horizontaliai'
  ),
  'table_cell_split_vertical' => array(
    'title' => 'Padalinti laukelДЇ vertikaliai'
  ),
  'style' => array(
    'title' => 'Stilius'
  ),
  'fontname' => array(
    'title' => 'Е riftas'
  ),
  'fontsize' => array(
    'title' => 'Dydis'
  ),
  'formatBlock' => array(
    'title' => 'Paragrafas'
  ),
  'bold' => array(
    'title' => 'Stambus ЕЎriftas (Bold)'
  ),
  'italic' => array(
    'title' => 'Kursyvas (Italic)'
  ),
  'underline' => array(
    'title' => 'Pabrauktas (Underline)'
  ),
  'strikethrough' => array(
    'title' => 'Perbrauktas (Strikethrough)'
  ),
  'insertorderedlist' => array(
    'title' => 'Numeruotas sД…raЕЎas'
  ),
  'insertunorderedlist' => array(
    'title' => 'SД…raЕЎas'
  ),
  'indent' => array(
    'title' => 'Stumti ДЇ deЕЎinД™'
  ),
  'outdent' => array(
    'title' => 'Stumti ДЇ kairД™'
  ),
  'justifyleft' => array(
    'title' => 'KairД—'
  ),
  'justifycenter' => array(
    'title' => 'Centras'
  ),
  'justifyright' => array(
    'title' => 'DeЕЎinД—'
  ),
  'justifyfull' => array(
    'title' => 'Plotis'
  ),
  'fore_color' => array(
    'title' => 'Teksto spalva'
  ),
  'bg_color' => array(
    'title' => 'Fono spalva'
  ),
  'design' => array(
    'title' => 'Perjungti ДЇ grafinio redagavimo reЕѕimД…'
  ),
  'html' => array(
    'title' => 'Perjungti ДЇ HTML kodo redagavimo reЕѕimД…'
  ),
  'colorpicker' => array(
    'title' => 'Spalvos pasirinkimas',
    'ok' => '   GERAI   ',
    'cancel' => 'Nutraukti'
  ),
  'cleanup' => array(
    'title' => 'HTML valymas (panaikinti stilius)',
    'confirm' => 'Atlikus ЕЎДЇ veiksmД… bus panaikinti visi tekste naudojami stiliai, ЕЎriftai ir nenaudojamos Еѕymos. Dalis ar visas formatavimas gali bЕ«ti prarastas.',
    'ok' => '   GERAI   ',
    'cancel' => 'Nutraukti',
  ),
  'toggle_borders' => array(
    'title' => 'Д®jungti/iЕЎjungti rД—melius',
  ),
  'hyperlink' => array(
    'title' => 'Nuoroda',
    'url' => 'Adresas',
    'name' => 'Vardas',
    'target' => 'Kur atidaryti',
    'title_attr' => 'Pavadinimas',
  	'a_type' => 'Tipas',
  	'type_link' => 'Nuoroda',
  	'type_anchor' => 'Inkaras',
  	'type_link2anchor' => 'Nuoroda ДЇ inkarД…',
  	'anchors' => 'Inkarai',
  	'quick_links' => "Greitos nuorodos", // <=== new in 2.0.6
    'ok' => '   GERAI   ',
    'cancel' => 'Nutraukti',
  ),
  'hyperlink_targets' => array(
  	'_self' => 'tame paДЌiame lange (_self)',
	'_blank' => 'naujame tuЕЎДЌiame lange (_blank)',
	'_top' => 'pagrindiniame lange (_top)',
	'_parent' => 'tД—viniame lange (_parent)'
  ),
  'unlink' => array( 
    'title' => 'PaЕЎalinti nuorodД…'
  ),
  'table_row_prop' => array(
    'title' => 'EilutД—s parametrai',
    'horizontal_align' => 'Horizontalus lygiavimas',
    'vertical_align' => 'Vertikalus lygiavimas',
    'css_class' => 'CSS klasД—',
    'no_wrap' => 'Neperkeliamas',
    'bg_color' => 'Fono spalva',
    'ok' => '   GERAI   ',
    'cancel' => 'Nutraukti',
    'left' => 'KairД—',
    'center' => 'Centras',
    'right' => 'DeЕЎinД—',
    'top' => 'VirЕЎus',
    'middle' => 'Vidurys',
    'bottom' => 'ApaДЌia',
    'baseline' => 'Teksto apaДЌia',
  ),
  'symbols' => array(
    'title' => 'SpecialЕ«s simboliai',
    'ok' => '   GERAI   ',
    'cancel' => 'AtЕЎaukti',
  ),
  'templates' => array(
    'title' => 'Е ablonai',
  ),
  'page_prop' => array(
    'title' => 'Puslapio parametrai',
    'title_tag' => 'Pavadinimas',
    'charset' => 'SimboliЕі rinkinys (Charset)',
    'background' => 'Fono paveiksliukas',
    'bgcolor' => 'Fono spalva',
    'text' => 'Teksto spalva',
    'link' => 'Nuorodos spalva',
    'vlink' => 'Aplankytos nuorodos spalva',
    'alink' => 'Aktyvios nuorodos spalva',
    'leftmargin' => 'ParaЕЎtД— kairД—je',
    'topmargin' => 'ParaЕЎtД— virЕЎuje',
    'css_class' => 'CSS klasД—',
    'ok' => '   GERAI   ',
    'cancel' => 'Nutraukti',
  ),
  'preview' => array(
    'title' => 'PerЕѕiЕ«ra',
  ),
  'image_popup' => array(
    'title' => 'IЕЎЕЎokantis paveiksliukas',
  ),
  'zoom' => array(
    'title' => 'Mastelis',
  ),
  'subscript' => array(
    'title' => 'Nuleistas tekstas',
  ),
  'superscript' => array(
    'title' => 'Pakeltas tekstas',
  ),
);
?>