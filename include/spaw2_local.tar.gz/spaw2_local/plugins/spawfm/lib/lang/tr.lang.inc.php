п»ї<?php 
// ================================================
// SPAW File Manager plugin
// ================================================
// Turkish language file
// ================================================
// Developed: Saulius Okunevicius, saulius@solmetra.com
// Translated: SД±tkД± Г–ZKURT, sitki@pragmamx.org
// Copyright: Solmetra (c)2006 All rights reserved.
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.1.0, 2006-11-20
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'
$spaw_lang_data = array(
  'spawfm' => array(
    'title' => 'SPAW Dosya YГ¶netimi',
    'error_reading_dir' => 'Hata: Dizin okunamД±yor.',
    'error_upload_forbidden' => 'Hata: Bu dizine dosya yГјklemesi izinli deДџil.',
    'error_upload_file_too_big' => 'YГјkleme baЕџarД±sД±z. Dosya Г§ok bГјyГјk.',
    'error_upload_failed' => 'YГјkleme baЕџarД±sД±z.',
    'error_upload_file_incomplete' => 'Dosya yГјkleme iГ§in komple deДџil. Tekrar deneyin.',
    'error_bad_filetype' => 'Hata: Bu dosya tipi izinli deДџil.',
    'error_max_filesize' => 'Maksimum izinli dosya bГјyГјklГјДџГј:',
    'error_delete_forbidden' => 'Hata: Bu dizinde dosya silinmesi izinli deДџil.',
    'confirm_delete' => 'Emin misiniz, bu dosyayД± "[*file*]" silmek istediДџinizden?',
    'error_delete_failed' => 'Hata: Dosya silinemedi. Muhtemelen gerekli haklarД±nД±z bulunmuyor.',
    'error_no_directory_available' => 'Aranabilecek dizin mevcut deДџil.',
    'download_file' => '[DosyayД± indir]',
    'error_chmod_uploaded_file' => 'DosyanД±n yГјklemesi baЕџarД±lД±ydД±, fakat kullanД±cД± haklarД±n verilmesi baЕџarД±sД±z.',
    'error_img_width_max' => 'Maksimum izinli resim geniЕџliДџi: [*MAXWIDTH*]px',
    'error_img_height_max' => 'Maksimum izinli resim yГјksekliДџi: [*MAXHEIGHT*]px',
    'rename_text' => 'Bu dosya iГ§in "[*FILE*]" yeni bir dosya ismi girin:',
    'error_rename_file_missing' => 'Yeniden adlandД±rma baЕџarД±sД±z - Dosya bulunamadД±.',
    'error_rename_directories_forbidden' => 'Hata: Dizinlerin bu dizinde yeniden adlandД±rД±lmasД± izinli deДџil.',
    'error_rename_forbidden' => 'Hata: DosyalarД±n bu dizinde yeniden adlandД±rД±lmasД± izinli deДџil.',
    'error_rename_file_exists' => 'Hata: Bu dosya "[*FILE*]" zaten mevcut.',
    'error_rename_failed' => 'Hata: Yeniden adlandД±rma baЕџarД±sД±z. Muhtemelen gerekli haklarД±nД±z bulunmuyor.',
    'error_rename_extension_changed' => 'Hata: Dosya isim eklentileri deДџiЕџtirilemez!',
    'newdirectory_text' => 'Dizin iГ§in bir isim girin:',
    'error_create_directories_forbidden' => 'Hata: Dizin Гјretilmesi yasaktД±r',
    'error_create_directories_name_used' => 'Д°sim zaten kullanД±lmakta, baЕџka birini deneyin.',
    'error_create_directories_failed' => 'Hata: Dizin Гјretilemedi. Muhtemelen gerekli haklarД±nД±z bulunmuyor.',
    'error_create_directories_name_invalid' => 'Bu iЕџaretler dizin isimlerinde kullanД±lamaz: / \\ : * ? " < > |',
    'confirmdeletedir_text' => 'Emin misiniz, bu dizini "[*DIR*]" silmek istediДџinizden?',
    'error_delete_subdirectories_forbidden' => 'Dizin silinmesi yasaktД±r.',
    'error_delete_subdirectories_failed' => 'Dizin silinemedi. Muhtemelen gerekli haklarД±nД±z bulunmuyor.',
    'error_delete_subdirectories_not_empty' => 'Dizin boЕџ deДџil.',
  ),
  'buttons' => array(
    'ok'        => '  OK  ',
    'cancel'    => 'Д°ptal',
    'view_list' => 'Modus: Liste',
    'view_details' => 'Modus: Detaylar',
    'view_thumbs' => 'Modus: Г–nizleme',
    'rename'    => 'Yeniden adlandД±rmak...',
    'delete'    => 'Sil',
    'go_up'     => 'YГјzey yukarД±da',
    'upload'    =>  'YГјkleme',
    'create_directory'  =>  'Yeni dizin...',
  ),
  'file_details' => array(
    'name'  =>  'Д°sim',
    'type'  =>  'Tip',
    'size'  =>  'BГјyГјklГјk',
    'date'  =>  'Tarih deДџiЕџtirildi',
    'filetype_suffix'  =>  'Dosya',
    'img_dimensions'  =>  'Boyut',
    'file_folder'  =>  'Dosya klasГ¶rГј',
  ),
  'filetypes' => array(
    'any'       => 'TГјm dosyalar (*.*)',
    'images'    => 'Resim dosyalarД±',
    'flash'     => 'Flash filmleri',
    'documents' => 'Belgeler',
    'audio'     => 'Audio dosyalarД±',
    'video'     => 'Video dosyalarД±',
    'archives'  => 'ArЕџiv dosyalarД±',
    '.jpg'  =>  'JPG resim dosyasД±',
    '.jpeg'  =>  'JPG resim dosyasД±',
    '.gif'  =>  'GIF resim dosyasД±',
    '.png'  =>  'PNG resim dosyasД±',
    '.swf'  =>  'Flash filmi',
    '.doc'  =>  'Microsoft Word belgesi',
    '.xls'  =>  'Microsoft Excel belgesi',
    '.pdf'  =>  'PDF belgesi',
    '.rtf'  =>  'RTF belgesi',
    '.odt'  =>  'OpenDocument Teksti',
    '.ods'  =>  'OpenDocument Elektronik tablosu',
    '.sxw'  =>  'OpenOffice.org 1.0 Tekst belgesi',
    '.sxc'  =>  'OpenOffice.org 1.0 Elektronik tablosu',
    '.wav'  =>  'WAV Audio dosyasД±',
    '.mp3'  =>  'MP3 Audio dosyasД±',
    '.ogg'  =>  'Ogg Vorbis Audio dosyasД±',
    '.wma'  =>  'Windows Audio dosyasД±',
    '.avi'  =>  'AVI Video dosyasД±',
    '.mpg'  =>  'MPEG Video dosyasД±',
    '.mpeg'  =>  'MPEG Video dosyasД±',
    '.mov'  =>  'QuickTime Video dosyasД±',
    '.wmv'  =>  'Windows Video dosyasД±',
    '.zip'  =>  'ZIP ArЕџivi',
    '.rar'  =>  'RAR ArЕџivi',
    '.gz'  =>  'gzip ArЕџivi',
    '.txt'  =>  'Text belgesi',
    ''  =>  '',
  ),
);
?>