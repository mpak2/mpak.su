<?php 
// ================================================
// SPAW PHP WYSIWYG editor control
// ================================================
// Polish language file
// ================================================
// Developed: Alan Mendelevich, alan@solmetra.lt
// Copyright: Solmetra (c)2003 All rights reserved.
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// polish bersion by Slawomir Jasinski slav123@gmail.com
// v.1.0.7, 2004-10-13
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'Wytnij'
  ),
  'copy' => array(
    'title' => 'Kopiuj'
  ),
  'paste' => array(
    'title' => 'Wklej'
  ),
  'undo' => array(
    'title' => 'Cofnij'
  ),
  'redo' => array(
    'title' => 'PonГіw'
  ),
  'image_insert' => array(
    'title' => 'Wstaw obrazek',
    'select' => 'Wybierz',
	'delete' => 'UsuЕ„', // new 1.0.5
    'cancel' => 'Anuluj',
    'library' => 'Biblioteka',
    'preview' => 'PodglД…d',
    'images' => 'Obrazki',
    'upload' => 'WyЕ›lij obrazek',
    'upload_button' => 'WyЕ›lij',
    'error' => 'BЕ‚Д…d',
    'error_no_image' => 'ProszД™ wybraД‡ obrazek',
    'error_uploading' => 'Przy wysyЕ‚aniu obrazka wystД…piЕ‚ bЕ‚Д…d. ProszД™ sprГіbowaД‡ pГіЕєniej.',
    'error_wrong_type' => 'NiewЕ‚aЕ›ciwy typ pliku obrazka',
    'error_no_dir' => 'Brak biblioteki obrazkГіw',
	'error_cant_delete' => 'BЕ‚Д…d usuwania', // new 1.0.5
  ),
  'image_prop' => array(
    'title' => 'WЕ‚aЕ›ciwoЕ›ci obrazka',
    'ok' => '   OK   ',
    'cancel' => 'Anuluj',
    'source' => 'ЕљcieЕјka',
    'alt' => 'Tekst alternatywny',
    'align' => 'WyrГіwnanie',
    'justifyleft' => 'justifyleft',
    'justifyright' => 'justifyright',
    'top' => 'top',
    'middle' => 'middle',
    'bottom' => 'bottom',
    'absmiddle' => 'absmiddle',
    'texttop' => 'texttop',
    'baseline' => 'baseline',
    'width' => 'SzerokoЕ›Д‡',
    'height' => 'WysokoЕ›Д‡',
    'border' => 'Obramowanie',
    'hspace' => 'OdstД™p poziomy',
    'vspace' => 'OdstД™p pionowy',
    'error' => 'BЕ‚Д…d',
    'error_width_nan' => 'SzerokoЕ›Д‡ nie jest liczbД…',
    'error_height_nan' => 'WysokoЕ›Д‡ nie jest liczbД…',
    'error_border_nan' => 'Ramka nie jest liczbД…',
    'error_hspace_nan' => 'OdstД™p poziomy nie jest liczbД…',
    'error_vspace_nan' => 'OdstД™p pionowy nie jest liczbД…',
  ),
  'inserthorizontalrule' => array(
    'title' => 'Linia pozioma'
  ),
  'table_create' => array(
    'title' => 'Wstaw tabelД™'
  ),
  'table_prop' => array(
    'title' => 'WЕ‚aЕ›ciwoЕ›ci tabeli',
    'ok' => '   OK   ',
    'cancel' => 'Anuluj',
    'rows' => 'Liczba wierszy',
    'columns' => 'Liczba kolumn',
    'css_class' => 'Styl CSS', // <=== new 1.0.6
    'width' => 'SzerokoЕ›Д‡',
    'height' => 'WysokoЕ›Д‡',
    'border' => 'Obramowanie',
    'pixels' => 'pikseli',
    'cellpadding' => 'Margines komГіrki',
    'cellspacing' => 'Obramowanie komГіrki',
    'bg_color' => 'Kolor tЕ‚a',
    'background' => 'Obrazek tЕ‚a', // <=== new 1.0.6
    'error' => 'BЕ‚Д…d',
    'error_rows_nan' => 'Liczba wierszy nie jest liczbД…',
    'error_columns_nan' => 'Liczba kolumn nie jest liczbД…',
    'error_width_nan' => 'SzerokoЕ›Д‡ nie jest liczbД…',
    'error_height_nan' => 'WysokoЕ›Д‡ nie jest liczbД…',
    'error_border_nan' => 'Obramowanie nie jest liczbД…',
    'error_cellpadding_nan' => 'Margines komГіrki nie jest liczbД…',
    'error_cellspacing_nan' => 'Obramowanie komГіrki nie jest liczbД…',
  ),
  'table_cell_prop' => array(
    'title' => 'WЕ‚aЕ›ciwoЕ›ci komГіrki',
    'horizontal_align' => 'WyrГіwnanie w poziomie',
    'vertical_align' => 'WyrГіwnanie w pionie',
    'width' => 'SzerokoЕ›Д‡',
    'height' => 'WysokoЕ›Д‡',
    'css_class' => 'styl CSS',
    'no_wrap' => 'Blokuj dzielenie akapitu',
    'bg_color' => 'Kolor tЕ‚a',
    'background' => 'Obrazek tЕ‚a', // <=== new 1.0.6
    'ok' => '   OK   ',
    'cancel' => 'Anuluj',
    'justifyleft' => 'Do lewej',
    'justifycenter' => 'Do Е›rodka',
    'justifyright' => 'Do prawej',
    'top' => 'Do gГіry',
    'middle' => 'Do Е›rodka',
    'bottom' => 'Do doЕ‚u',
    'baseline' => 'Do linii bazowej',
    'error' => 'BЕ‚Д…d',
    'error_width_nan' => 'SzerokoЕ›Д‡ nie jest liczbД…',
    'error_height_nan' => 'WysokoЕ›Д‡ nie jest liczbД…',
  ),
  'table_row_insert' => array(
    'title' => 'Wstaw wiersz'
  ),
  'table_column_insert' => array(
    'title' => 'Wstaw kolumnД™'
  ),
  'table_row_delete' => array(
    'title' => 'UsuЕ„ wiersz'
  ),
  'table_column_delete' => array(
    'title' => 'UsuЕ„ kolumnД™'
  ),
  'table_cell_merge_right' => array(
    'title' => 'PoЕ‚Д…cz z prawД…'
  ),
  'table_cell_merge_down' => array(
    'title' => 'PoЕ‚Д…cz z dolnД…'
  ),
  'table_cell_split_horizontal' => array(
    'title' => 'Podziel komГіrkД™ w poziomie'
  ),
  'table_cell_split_vertical' => array(
    'title' => 'Podziel komГіrkД™ w pionie'
  ),
  'style' => array(
    'title' => 'Styl'
  ),
  'fontname' => array(
    'title' => 'Czcionka'
  ),
  'fontsize' => array(
    'title' => 'Rozmiar'
  ),
  'formatBlock' => array(
    'title' => 'Akapit'
  ),
  'bold' => array(
    'title' => 'Pogrubienie'
  ),
  'italic' => array(
    'title' => 'Kursywa'
  ),
  'underline' => array(
    'title' => 'PodkreЕ›lenie'
  ),
  'insertorderedlist' => array(
    'title' => 'Numerowanie'
  ),
  'insertunorderedlist' => array(
    'title' => 'Wypunktowanie'
  ),
  'indent' => array(
    'title' => 'ZwiД™ksz wciД™cie'
  ),
  'outdent' => array(
    'title' => 'Zmniejsz wciД™cie'
  ),
  'justifyleft' => array(
    'title' => 'WyrГіwnaj do lewej'
  ),
  'justifycenter' => array(
    'title' => 'WyЕ›rodkuj'
  ),
  'justifyright' => array(
    'title' => 'WyrГіwnaj do prawej'
  ),
  'fore_color' => array(
    'title' => 'Kolor czcionki'
  ),
  'bg_color' => array(
    'title' => 'Kolor tЕ‚a'
  ),
  'design' => array(
    'title' => 'PrzeЕ‚Д…cz w tryb podglД…du (WYSIWYG)'
  ),
  'html' => array(
    'title' => 'PrzeЕ‚Д…cz w tryb HTML (kod)'
  ),
  'colorpicker' => array(
    'title' => 'WybГіr koloru',
    'ok' => '   OK   ',
    'cancel' => 'Anuluj',
  ),
  'cleanup' => array(
    'title' => 'czyszczenie HTML (usuwanie styli)',
    'confirm' => 'Przeprowadzenie tej operacji usunie wszystkie style, okreЕ›lenia czcionek i zbД™dne znaczniki z bieЕјД…cej treЕ›ci. CzД™Е›Д‡ lub caЕ‚oЕ›Д‡ formatowania moЕјe zostaД‡ utracona.',
    'ok' => '   OK   ',
    'cancel' => 'Anuluj',
  ),
  'toggle_borders' => array(
    'title' => 'PrzeЕ‚Д…cz obramowania',
  ),
  'hyperlink' => array(
    'title' => 'OdsyЕ‚acz',
    'url' => 'Adres URL',
    'name' => 'Nazwa',
    'target' => 'Okno docelowe',
    'title_attr' => 'TytuЕ‚',
	'a_type' => 'Typ', // <=== new 1.0.6
	'type_link' => 'Link', // <=== new 1.0.6
	'type_anchor' => 'Kotwica', // <=== new 1.0.6
	'type_link2anchor' => 'Adres kotwicy', // <=== new 1.0.6
    'anchors' => 'Kotwice', // <=== new 1.0.6
    'ok' => '   OK   ',
    'cancel' => 'Anuluj',
  ),
  'hyperlink_targets' => array( // <=== new 1.0.5
  	'_self' => 'to samo (_self)',
	'_blank' => 'nowe okno (_blank)',
	'_top' => 'gГіrna ramka (_top)',
	'_parent' => 'nadrzД™dna ramka (_parent)'
  ),
  'table_row_prop' => array(
    'title' => 'WЕ‚aЕ›ciwosci wiersza',
    'horizontal_align' => 'WyrГіwnanie w poziomie',
    'vertical_align' => 'WyrГіwnanie w pionie',
    'css_class' => 'styl CSS',
    'no_wrap' => 'Blokuj dzielenie akapitu',
    'bg_color' => 'Kolor tЕ‚a',
    'ok' => '   OK   ',
    'cancel' => 'Anuluj',
    'justifyleft' => 'WyrГіwnaj do lewej',
    'justifycenter' => 'Do Е›rodka',
    'justifyright' => 'Do prawej',
    'top' => 'Do gГіry',
    'middle' => 'Do Е›rodka',
    'bottom' => 'Do doЕ‚u',
    'baseline' => 'Do linii bazowej',
  ),
  'symbols' => array(
    'title' => 'Znaki specjalne',
    'ok' => '   OK   ',
    'cancel' => 'Anuluj',
  ),
  'templates' => array(
    'title' => 'Szablony',
  ),
  'page_prop' => array(
    'title' => 'WЕ‚aЕ›ciwoЕ›ci strony',
    'title_tag' => 'TytyЕ‚',
    'charset' => 'Strona kodowa',
    'background' => 'Obraz tЕ‚a',
    'bgcolor' => 'Kolor tЕ‚a',
    'text' => 'Kolor tekstu',
    'link' => 'Kolor odsyЕ‚acza',
    'vlink' => 'Kolor wybranego odsyЕ‚acza',
    'alink' => 'Kolor aktywnego odsyЕ‚acza',
    'leftmargin' => 'Margines lewy',
    'topmargin' => 'Margines gГіrny',
    'css_class' => 'Styl CSS',
    'ok' => '   OK   ',
    'cancel' => 'Anuluj',
  ),
  'preview' => array(
    'title' => 'PodglД…d',
  ),
  'image_popup' => array(
    'title' => 'Image popup',
  ),
  'zoom' => array(
    'title' => 'Zoom',
  ),
  'subscript' => array( // <=== new 1.0.7
    'title' => 'Indeks dolny',
  ),
  'superscript' => array( // <=== new 1.0.7
    'title' => 'Indeks gГіrny',
  ),
);
?>