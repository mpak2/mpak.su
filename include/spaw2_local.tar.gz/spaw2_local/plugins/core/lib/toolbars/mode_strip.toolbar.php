<?php
$items = array
(
  new SpawTbButton("core", "design", "isDesignModeEnabled", "isHtmlModeEnabled", "designModeClick"),
  new SpawTbButton("core", "html", "isHtmlModeEnabled", "isDesignModeEnabled", "htmlModeClick"),
);
?>
