<?php
// ================================================
// SPAW PHP WYSIWYG editor control
// ================================================
// English language file
// ================================================
// Developed: Alan Mendelevich, alan@solmetra.lt
// Copyright: Solmetra (c)2003 All rights reserved.
// Greek translation: Saxinidis B. Konstantinos
//                    skva@in.gr
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.1.0, 2003-03-20
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'О‘ПЂОїОєОїПЂО®'
  ),
  'copy' => array(
    'title' => 'О‘ОЅП„О№ОіПЃО±П†О®'
  ),
  'paste' => array(
    'title' => 'О•ПЂО№ОєПЊО»О»О·ПѓО·'
  ),
  'undo' => array(
    'title' => 'О‘ОЅО±ОЇПЃОµПѓО·'
  ),
  'redo' => array(
    'title' => 'О‘ОєПЌПЃП‰ПѓО· О‘ОЅО±ОЇПЃОµПѓО·П‚'
  ),
  'hyperlink' => array(
    'title' => 'ОҐПЂОµПЃПѓПЌОЅОґОµПѓО·'
  ),
  'image_insert' => array(
    'title' => 'О•О№ПѓО±ОіП‰ОіО® ОµО№ОєПЊОЅО±П‚',
    'select' => 'О•ПЂО№О»ОїОіО®',
    'cancel' => 'вЂ™ОєП…ПЃОї',
    'library' => 'О’О№ОІО»О№ОїОёО®ОєО·',
    'preview' => 'О ПЃОїОµПЂО№ПѓОєПЊПЂО·ПѓО·',
    'images' => 'О•О№ОєПЊОЅОµП‚',
    'upload' => 'О¦ПЊПЃП„П‰ОјО± ОµО№ОєПЊОЅО±П‚',
    'upload_button' => 'О¦ПЊПЃП„П‰ОјО±',
    'error' => 'О›О¬ОёОїП‚',
    'error_no_image' => 'О О±ПЃО±ОєО±О»ПЋ ОµПЂО№О»О­ОѕП„Оµ ОјО№О± ОµО№ОєПЊОЅО±',
    'error_uploading' => 'О€ОЅО± О»О¬ОёОїП‚ ОµОЅПЋ П„Ої ОґО№О±П‡ОµО№ПЃО№О¶ПЊОјОµОЅОї О±ПЃП‡ОµОЇОї П†ОїПЃП„ПЋОЅОїОЅП„О±ОЅ.  О О±ПЃО±ОєО±О»ПЋ ПЂПЃОїПѓПЂО±ОёО®ПѓП„Оµ ПЂО¬О»О№ О±ПЃОіПЊП„ОµПЃО±',
    'error_wrong_type' => 'О›О±ОЅОёО±ПѓОјО­ОЅОїП‚ П„ПЌПЂОїП‚ О±ПЃП‡ОµОЇОїП… ОµО№ОєПЊОЅО±П‚',
    'error_no_dir' => 'О— ОІО№ОІО»О№ОїОёО®ОєО· ОґОµОЅ ОґО·ОјО№ОїП…ПЃОіО®ОёО·ОєОµ ОјОµ П†П…ПѓО№ОєПЊ П„ПЃОїПЂОї О® ОґОµОЅ П…ПЂО¬ПЃП‡ОµО№',
  ),
  'image_prop' => array(
    'title' => 'О™ОґО№ПЊП„О·П„ОµП‚ ОµО№ОєПЊОЅО±П‚',
    'ok' => '   OK   ',
    'cancel' => 'вЂ™ОєП…ПЃОї',
    'source' => 'О ПЃОїО­О»ОµП…ПѓО·',
    'alt' => 'О•ОЅО±О»О»О±ОєП„О№ОєПЊ ОєОµОЇОјОµОЅОї',
    'align' => 'О•П…ОёП…ОіПЃО±ОјОјОЇПѓО·',
    'justifyleft' => 'О±ПЃО№ПѓП„ОµПЃО¬',
    'justifyright' => 'ОґОµОѕО№О¬',
    'full' => 'justifyfull',
    'top' => 'ПЂО¬ОЅП‰',
    'middle' => 'ОјО­ПѓО·',
    'bottom' => 'ОєО¬П„П‰',
    'absmiddle' => 'absОјО­ПѓО·',
    'texttop' => 'texttop',
    'baseline' => 'baseline',
    'width' => 'О О»О¬П„ОїП‚',
    'height' => 'ОЋП€ОїП‚',
    'border' => 'О ОµПЃОЇОіПЃО±ОјОјО±',
    'hspace' => 'ОџПЃО№О¶. space',
    'vspace' => 'ОљО¬ОёОµП„. space',
    'error' => 'О›О¬ОёОїП‚',
    'error_width_nan' => 'О¤Ої ПЂО»О¬П„ОїП‚ ОґОµОЅ ОµОЇОЅО±О№ О­ОЅО±П‚ О±ПЃО№ОёОјПЊП‚',
    'error_height_nan' => 'ОЋП€ОїП‚ ОґОµОЅ ОµОЇОЅО±О№ О­ОЅО±П‚ О±ПЃО№ОёОјПЊП‚',
    'error_border_nan' => 'Border ОґОµОЅ ОµОЇОЅО±О№ О­ОЅО±П‚ О±ПЃО№ОёОјПЊП‚',
    'error_hspace_nan' => 'О¤Ої ОїПЃО№О¶ПЊОЅП„О№Ої ОґО№О¬ПѓП„О·ОјО± ОґОµОЅ ОµОЇОЅО±О№ О­ОЅО±П‚ О±ПЃО№ОёОјПЊП‚',
    'error_vspace_nan' => 'О¤Ої ОєО¬ОёОµП„Ої ОґО№О¬ПѓП„О·ОјО± ОґОµОЅ ОµОЇОЅО±О№ О­ОЅО±П‚ О±ПЃО№ОёОјПЊП‚',
  ),
  'inserthorizontalrule' => array(
    'title' => 'ОџПЃО№О¶ПЊОЅП„О№ОїП‚ ОєО±ОЅПЊОЅО±П‚'
  ),
  'table_create' => array(
    'title' => 'О”О·ОјО№ОїП…ПЃОіО®ПѓП„Оµ ПЂОЇОЅО±ОєО±'
  ),
  'table_prop' => array(
    'title' => 'О™ОґО№ПЊП„О·П„ОµП‚ ПЂОЇОЅО±ОєО±',
    'ok' => '   OK   ',
    'cancel' => 'О‘ОєП…ПЃОї',
    'rows' => 'ОЈОµО№ПЃО­П‚',
    'columns' => 'ОЈП„О®О»ОµП‚',
    'width' => 'О О»О¬П„ОїП‚',
    'height' => 'ОЋП€ОїП‚',
    'border' => 'О ОµПЃОЇОіПЃО±ОјОјО±',
    'pixels' => 'pixels',
    'cellpadding' => 'О“О­ОјО№ПѓОјО± ОєОµО»О№ОїПЌ',
    'cellspacing' => 'О”О№О¬ПѓП„О·ОјО± ОєОµО»О№ОїПЌ',
    'bg_color' => 'Background П‡ПЃПЋОјО±',
    'error' => 'О›О¬ОёОїП‚',
    'error_rows_nan' => 'ОџО№ ПѓОµО№ПЃО­П‚ ОґОµОЅ ОµОЇОЅО±О№ О­ОЅО±П‚ О±ПЃО№ОёОјПЊП‚',
    'error_columns_nan' => 'ОџО№ ПѓП„О®О»ОµП‚ ОґОµОЅ ОµОЇОЅО±О№ О­ОЅО±П‚ О±ПЃО№ОёОјПЊП‚',
    'error_width_nan' => 'О¤Ої ПЂО»О¬П„ОїП‚ ОґОµОЅ ОµОЇОЅО±О№ О­ОЅО±П‚ О±ПЃО№ОёОјПЊП‚',
    'error_height_nan' => 'ОЋП€ОїП‚ ОґОµОЅ ОµОЇОЅО±О№ О­ОЅО±П‚ О±ПЃО№ОёОјПЊП‚',
    'error_border_nan' => 'О¤Ої ПЂОµПЃОЇОіПЃО±ОјОјО± ОґОµОЅ ОµОЇОЅО±О№ О­ОЅО±П‚ О±ПЃО№ОёОјПЊП‚',
    'error_cellpadding_nan' => 'О¤Ої ОіО­ОјО№ПѓОјО± ОєОµО»О№ОїПЌ ОґОµОЅ ОµОЇОЅО±О№ О­ОЅО±П‚ О±ПЃО№ОёОјПЊП‚',
    'error_cellspacing_nan' => 'О¤Ої ОґО№О¬ПѓП„О·ОјО± ОєОµО»О№ОїПЌ ОґОµОЅ ОµОЇОЅО±О№ О­ОЅО±П‚ О±ПЃО№ОёОјПЊП‚',
  ),
  'table_cell_prop' => array(
    'title' => ' О№ОґО№ПЊП„О·П„ОµП‚ ОЈП„О·О»ПЋОЅ',
    'horizontal_align' => 'ОџПЃО№О¶ПЊОЅП„О№О± ОµП…ОёП…ОіПЃО¬ОјОјО№ПѓО·',
    'vertical_align' => 'ОљО¬ОёОµП„О· ОµП…ОёП…ОіПЃО¬ОјОјО№ПѓО·',
    'width' => 'О О»О¬П„ОїП‚',
    'height' => 'ОЋП€ОїП‚',
    'css_class' => 'CSS class',
    'no_wrap' => 'No wrap',
    'bg_color' => 'Background color',
    'ok' => '   OK   ',
    'cancel' => 'вЂ™ОєП…ПЃОї',
    'justifyleft' => 'О‘ПЃО№ПѓП„ОµПЃО¬',
    'justifycenter' => 'ОљО­ОЅП„ПЃОї',
    'justifyright' => 'О”ОµОѕО№О¬',
    'full' => 'Justify',
    'top' => 'Top',
    'middle' => 'Middle',
    'bottom' => 'Bottom',
    'baseline' => 'Baseline',
    'error' => 'О›О¬ОёОїП‚',
    'error_width_nan' => 'О¤Ої ПЂО»О¬П„ОїП‚ ОґОµОЅ ОµОЇОЅО±О№ О­ОЅО±П‚ О±ПЃО№ОёОјПЊП‚',
    'error_height_nan' => 'ОЋП€ОїП‚ ОґОµОЅ ОµОЇОЅО±О№ О­ОЅО±П‚ О±ПЃО№ОёОјПЊП‚',
  ),
  'table_row_insert' => array(
    'title' => 'О•О№ПѓО±ОіП‰ОіО® ПѓОµО№ПЃО¬П‚'
  ),
  'table_column_insert' => array(
    'title' => 'О•О№ПѓО±ОіП‰ОіО® ПѓП„О®О»О·П‚'
  ),
  'table_row_delete' => array(
    'title' => 'О”О№О±ОіПЃО±П†О® ПѓОµО№ПЃО¬П‚'
  ),
  'table_column_delete' => array(
    'title' => 'О”О№О±ОіПЃО±П†О® ПѓП„О®О»О·П‚'
  ),
  'table_cell_merge_right' => array(
    'title' => 'Merge ОґОµОѕО№О¬'
  ),
  'table_cell_merge_down' => array(
    'title' => 'Merge ОєО¬П„П‰'
  ),
  'table_cell_split_horizontal' => array(
    'title' => 'Split ОєОµО»О№ОїПЌ ОїПЃО№О¶ПЊОЅП„О№О±'
  ),
  'table_cell_split_vertical' => array(
    'title' => 'Split ОєОµО»О№ОїПЌ ОєО¬ОёОµП„О±'
  ),
  'style' => array(
    'title' => 'Style'
  ),
  'fontname' => array(
    'title' => 'О“ПЃО±ОјОјО±П„ОїПѓОµО№ПЃО¬'
  ),
  'fontsize' => array(
    'title' => 'ОњО­ОіОµОёОїП‚'
  ),
  'formatBlock' => array(
    'title' => 'О О±ПЃО¬ОіПЃО±П†ОїП‚'
  ),
  'bold' => array(
    'title' => 'О€ОЅП„ОїОЅО±'
  ),
  'italic' => array(
    'title' => 'Italic'
  ),
  'underline' => array(
    'title' => 'ОҐПЂОїОіПЃО¬ОјОјО№ПѓО·'
  ),
  'insertorderedlist' => array(
    'title' => 'О‘ПЃОЇОёОјО·ПѓО·'
  ),
  'insertunorderedlist' => array(
    'title' => 'ОєОїП…ОєОєОЇОґОµП‚'
  ),
  'indent' => array(
    'title' => 'О•ПѓОїП‡О®'
  ),
  'outdent' => array(
    'title' => 'О§П‰ПЃОЇП‚ ОµПѓОїП‡О®'
  ),
  'justifyleft' => array(
    'title' => 'О‘ПЃО№ПѓП„ОµПЃО¬'
  ),
  'justifycenter' => array(
    'title' => 'ОљО­ОЅП„ПЃОї'
  ),
  'justifyright' => array(
    'title' => 'О”ОµОѕО№О¬'
  ),
  'full' => array(
    'title' => 'Justify'
  ),
  'fore_color' => array(
    'title' => 'Fore color'
  ),
  'bg_color' => array(
    'title' => 'Background color'
  ),
  'design' => array(
    'title' => 'О‘О»О»О±ОіО® ПѓОµ WYSIWYG (design) mode'
  ),
  'html' => array(
    'title' => 'О‘О»О»О±ОіО® ПѓОµ HTML (code) mode'
  ),
  'colorpicker' => array(
    'title' => 'Color picker',
    'ok' => '   OK   ',
    'cancel' => 'вЂ™ОєП…ПЃОї',
  ),
  'cleanup' => array(
    'title' => 'HTML ОєО±ОёО±ПЃО№ПѓОјПЊП‚ (О±ПЂОїОјО¬ОєПЃП…ОЅПѓО· styles)',
    'confirm' => 'О— ОµОєП„О­О»ОµПѓО· О±П…П„О® ОёО± О±П†О±О№ПЃО­ПѓОµО№ ПЊО»О± П„О± styles, fonts and useless tags О±ПЂПЊ П„Ої ПѓП…ОіОєОµОєПЃО№ОјО­ОЅОї content. ОљО¬ПЂОїО№О± О® ОєО±О№ ПЊО»ОµП‚ ОїО№  ОјОїПЃП†ОїПЂОїО№О®ПѓОµО№П‚ ПѓОїП… ОјПЂОїПЃОµОЇ ОЅО± П‡О±ОёОїПЌОЅ.',
    'ok' => '   OK   ',
    'cancel' => 'вЂ™ОєП…ПЃОї',
  ),
  'toggle_borders' => array(
    'title' => 'ОЊПЃО№О± ПЂОµПЃО№ОіПЃО±ОјОјО¬П„П‰ОЅ',
  ),
  'hyperlink' => array(
    'title' => 'ОҐПЂОµПЃПѓПЌОЅОґОµПѓО·',
    'url' => 'URL',
    'name' => 'ОЊОЅОїОјО±',
    'target' => 'ОЊПЃО№О±',
    'title_attr' => 'О¤ОЇП„О»ОїП‚',
    'ok' => '   OK   ',
    'cancel' => 'вЂ™ОєП…ПЃОї',
  ),
  'table_row_prop' => array(
    'title' => 'О™ОґО№ПЊП„О·П„ОµП‚ ОЈОµО№ПЃПЋОЅ',
    'horizontal_align' => 'ОџПЃО№О¶ПЊОЅП„О№О± ОµП…ОёП…ОіПЃО¬ОјОјО№ПѓО·',
    'vertical_align' => 'ОљО¬ОёОµП„О· ОµП…ОёП…ОіПЃО¬ОјОјО№ПѓО·',
    'css_class' => 'CSS class',
    'no_wrap' => 'No wrap',
    'bg_color' => 'Background color',
    'ok' => '   OK   ',
    'cancel' => 'вЂ™ОєП…ПЃОї',
    'justifyleft' => 'О‘ПЃО№ПѓП„ОµПЃО¬',
    'justifycenter' => 'ОљО­ОЅП„ПЃОї',
    'justifyright' => 'О”ОµОѕО№О¬',
    'full' => 'Justify',
    'top' => 'О О¬ОЅП‰',
    'middle' => 'ОњО­ПѓО·',
    'bottom' => 'ОљО¬П„П‰',
    'baseline' => 'Baseline',
  ),
  'symbols' => array(
    'title' => 'ОЈПЂОµПѓО№О±О» П‡О±ПЃО±ОєП„О®ПЃОµП‚',
    'ok' => '   OK   ',
    'cancel' => 'вЂ™ОєП…ПЃОї',
  ),
  'templates' => array(
    'title' => 'Templates',
  ),
  'page_prop' => array(
    'title' => 'О™ОґО№ПЊП„О·П„ОµП‚ ОЈОµО»ОЇОґО±П‚',
    'title_tag' => 'О¤ОЇП„О»ОїП‚',
    'charset' => 'Charset',
    'background' => 'Background ОµО№ОєПЊОЅО±',
    'bgcolor' => 'Background П‡ПЃПЋОјО±',
    'text' => 'О§ПЃПЋОјО± ОєОµО№ОјО­ОЅОїП…',
    'link' => 'О§ПЃПЋОјО± link',
    'vlink' => 'О§ПЃПЋОјО± link ПЂОїП… ОµПЂО№ПѓОєО­П†П„О·ОєО±ОЅ',
    'alink' => 'О§ПЃПЋОјО± О•ОЅОµПЃОіОїПЌ link ',
    'leftmargin' => 'О ОµПЃО№ОёПЋПЃО№Ої О‘ПЃО№ПѓП„ОµПЃПЊ',
    'topmargin' => 'О О¬ОЅП‰ О ОµПЃО№ОёПЋПЃО№Ої',
    'css_class' => 'CSS class',
    'ok' => '   OK   ',
    'cancel' => 'вЂ™ОєП…ПЃОї',
  ),
  'preview' => array(
    'title' => 'О ПЃОїОµПЂО№ПѓОєПЊПЂО·ПѓО·',
  ),
  'image_popup' => array(
    'title' => 'Image popup',
  ),
  'zoom' => array(
    'title' => 'Zoom',
  ),
);
?>