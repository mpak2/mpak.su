<?php 
// ================================================
// SPAW PHP WYSIWYG editor control
// ================================================
// Czech language file
// ================================================
// Developed: Alan Mendelevich, alan@solmetra.lt
// Copyright: Solmetra (c)2003 All rights reserved.
// Czech translation: BrM (BrM@bridlicna.cz)
// Updated by Radek UhlГ­Е™ (ruhlir@gmail.com)
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.1.1, 2007-09-04
// ================================================
 
 // charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'Vyjmout'
  ),
  'copy' => array(
    'title' => 'KopГ­rovat'
  ),
  'paste' => array(
    'title' => 'VloЕѕit'
  ),
  'undo' => array(
    'title' => 'ZpД›t'
  ),
  'redo' => array(
    'title' => 'Znovu'
  ),
  'image' => array(
    'title' => 'VloЕѕit obrГЎzek'
  ),
  'image_prop' => array(
    'title' => 'ObrГЎzek',
    'ok' => '   OK   ',
    'cancel' => 'Storno',
    'source' => 'Source',
    'alt' => 'AlternativnГ­ text',
    'align' => 'ZarovnГЎnГ­',
    'left' => 'vlevo',
    'right' => 'vpravo',
    'top' => 'nahoru',
    'middle' => 'na stЕ™ed',
    'bottom' => 'dolЕЇ',
    'absmiddle' => 'AbsolutnГ­ stЕ™ed',
    'texttop' => 'Text nahoru',
    'baseline' => 'ZГЎkladnГ­ linka',
    'width' => 'Е Г­Е™ka',
    'height' => 'VГЅЕЎka',
    'border' => 'Okraje',
    'hspace' => 'Vod. okraj',
    'vspace' => 'Svisl. okraj',
    'dimensions' => 'RozmД›ry', // <= new in 2.0.1
    'reset_dimensions' => 'PЕЇvodnГ­ rozmД›ry', // <= new in 2.0.1
    'title_attr' => 'Titulek', // <= new in 2.0.1
    'constrain_proportions' => 'Zachovat proporce', // <= new in 2.0.1
    'error' => 'Chyba',
    'error_width_nan' => 'Е Г­Е™ka nenГ­ ДЌГ­slo',
    'error_height_nan' => 'VГЅЕЎka nenГ­ ДЌГ­slo',
    'error_border_nan' => 'Okraj nenГ­ ДЌГ­slo',
    'error_hspace_nan' => 'HorizontГЎlnГ­ rozteДЌ nenГ­ ДЌГ­slo',
    'error_vspace_nan' => 'VertikГЎlnГ­ rozteДЌ nenГ­ ДЌГ­slo',
  ),
  'flash_prop' => array(                // <= new in 2.0
    'title' => 'Flash',
    'ok' => '   OK   ',
    'cancel' => 'Storno',
    'source' => 'Zdroj',
    'width' => 'Е Г­Е™ka',
    'height' => 'VГЅЕЎka',
    'error' => 'Chyba',
    'error_width_nan' => 'Е Г­Е™ka nenГ­ ДЌГ­slo.',
    'error_height_nan' => 'VГЅЕЎka nenГ­ ДЌГ­slo.',
  ),
  'inserthorizontalrule' => array( // <== v.2.0 changed from hr
    'title' => 'HorizontГЎlnГ­ ДЌГЎra'
  ),
  'table_create' => array(
    'title' => 'VytvoЕ™ tabulku'
  ),
  'table_prop' => array(
    'title' => 'Vlastnosti tabulky',
    'ok' => '   OK   ',
    'cancel' => 'Storno',
    'rows' => 'Е