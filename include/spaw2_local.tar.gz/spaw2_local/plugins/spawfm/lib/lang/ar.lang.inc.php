<?php 
// ================================================
// SPAW File Manager plugin
// ================================================
//
//
// Arabic language file
// Traslated: Mohammed Ahmed
// Gaza, Palestine
// http://www.maaking.com
// Email/MSN: m@maaking.com
//
// last update: 18-oct-2007
//
// ================================================
// Developed: Saulius Okunevicius, saulius@solmetra.com
// Copyright: Solmetra (c)2006 All rights reserved.
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.2.0
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'windows-1256';

// text direction for the language
$spaw_lang_direction = 'rtl';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'spawfm' => array(
    'title' => 'ЕПЗСЙ ЗбгбЭЗК',
    'error_reading_dir' => 'ОШГ: бЗ нгЯд ЮСЗБЙ гНКжнЗК ЗбгМбП',
    'error_upload_forbidden' => 'ОШГ: КНгнб ЗбгбЭЗК ЫнС гУгжН Эн еРЗ ЗбгМбП.',
    'error_upload_file_too_big' => 'ЭФ ЗбКНгнб: НМг ЗбгбЭ ЯИнС МПЗ..',
    'error_upload_failed' => 'ЭФ КНгнб ЗбгбЭ.',
    'error_upload_file_incomplete' => 'ЭФ Эн КНгнб ЗбгбЭЎ ЗбСМЗБ ЗбгНЗжбЙ гСм ГОСм.',
    'error_bad_filetype' => 'ОШГ: еРЗ ЗбджЪ гд ЗбгбЭЗК ЫнС гУгжН Ие.',
    'error_max_filesize' => 'ЗбНМг ЗбгУгжН Ие: ',
    'error_delete_forbidden' => 'ОШГ: НРЭ ЗбгбЭЗК Эн еРЗ ЗбгМбП ЫнС гУгжН Ие.',
    'confirm_delete' => 'еб КСнП НРЭ ЗбгбЭ "[*file*]"?',
    'error_delete_failed' => 'ОШГ: СИгЗ бЗ нжМП бЯ ХбЗНнЗК бНРЭ еРЗ ЗбгбЭ.',
    'error_no_directory_available' => 'бЗ нжМП гМбПЗК бКХЭНеЗ.',
    'download_file' => '[КНгнб ЗбгбЭ]',
    'error_chmod_uploaded_file' => 'Кг СЭЪ ЗбгбЭЎ бЯд бг нЪШм КХСнН CHMOD',
    'error_img_width_max' => 'ГЮХм ЪСЦ гУгжН Ие еж : [*MAXWIDTH*]px',
    'error_img_height_max' => 'ГЮХм ЕСКЭЗЪ гУгжН Ие еж : [*MAXHEIGHT*]px',
    'rename_text' => 'ГПОб ЗбЕУг ЗбМПнП бЬ  "[*FILE*]":',
    'error_rename_file_missing' => 'ЭФбК ЗЪЗПЙ ЗбКУгнЙЎ бг нКг ЗбЪЛжС Ъбм ЗбгбЭ.',
    'error_rename_directories_forbidden' => 'ОШГ: ЕЪЗПЙ ЗбКУгнЙ ЫнС гУгжНЙ беРЗ ЗбгМбП.',
    'error_rename_forbidden' => 'ОШГ: ЕЪЗПЙ ЗбКУгнЙ ЫнС гУгжНЙ беРЗ ЗбгМбП.',
    'error_rename_file_exists' => 'ОШГ: "[*FILE*]" гжМжП гУИЮЗ.',
    'error_rename_failed' => 'ОШГ: ЭФбК ЗЪЗПЙ ЗбКУгнЙ. ',
    'error_rename_extension_changed' => 'ОШГ: бЗ нгЯд КЫннС ЗбЗгКЗП!',
    'newdirectory_text' => 'ГЯКИ ЕУг ЗбгМбП:',
    'error_create_directories_forbidden' => 'ОШГ: бЗ нгЯд ЗбУгЗН ИЗдФЗБ гМбП',
    'error_create_directories_name_used' => 'ОШГ: еРЗ ЗбЗУг гжМжП гд ЮИб.',
    'error_create_directories_failed' => 'бЗнгЯд ЗдФЗБ ЗбгМбПЎ бЗ нжМП ХбЗНнЗК.',
    'error_create_directories_name_invalid' => 'бЗ нгЯд ЗУКОПЗг ЗбНСЭ ЗбКЗбнЙ Эн ЗбЗУг: / \\ : * ? " < > |',
    'confirmdeletedir_text' => 'еб КСнП НРЭ ЗбгМбП:  "[*DIR*]"?',
    'error_delete_subdirectories_forbidden' => 'бЗнгЯд НРЭ еРЗ ЗбгМбП.',
    'error_delete_subdirectories_failed' => 'бЗ нгЯд НРЭ ЗбгМбП. СИгЗ бнУ бПнЯ ХбЗНнЗК бЪгб РбЯ.',
    'error_delete_subdirectories_not_empty' => 'ЗбгМбП ЫнС ЭЗСЫ.',
  ),
  'buttons' => array(
    'ok'        => '  гжЗЭЮ  ',
    'cancel'    => 'ЕбЫЗБ',
    'view_list' => 'дЩЗг ЗбЪСЦ: ЮЗЖгЙ',
    'view_details' => 'дЩЗг ЗбЪСЦ: КЭЗХнб',
    'view_thumbs' => 'дЩЗг ЗбЪСЦ: гХЫСЗК',
    'rename'    => 'ЕЪЗПЙ КУгнЙ ... ',
    'delete'    => 'НРЭ',
    'go_up'     => 'бГЪбм',
    'upload'    =>  'ЕЭЪ ЗбгбЭ',
    'create_directory'  =>  'ЕдФЗБ гМбП',
  ),
  'file_details' => array(
    'name'  =>  'ЗУг',
    'type'  =>  'джЪ',
    'size'  =>  'НМг',
    'date'  =>  'КЗСнО ЗбКЪПнб',
    'filetype_suffix'  =>  'гбЭ',
    'img_dimensions'  =>  'ЗбГИЪЗП',
    'file_folder'  =>  'гбЭ гМбП',
  ),
  'filetypes' => array(
    'any'       => 'МгнЪ ЗбгбЭЗК (*.*)',
    'images'    => 'ХжС',
    'flash'     => 'ЭбЗФ',
    'documents' => 'жЛЗЖЮ',
    'audio'     => 'ХжК',
    'video'     => 'ЭПнПж',
    'archives'  => 'ГСФнЭ',
    '.jpg'  =>  'ХжСЙ JPG ',
    '.jpeg'  =>  'ХжСЙ JPG ',
    '.gif'  =>  'ХжСЙ GIF ',
    '.png'  =>  'ХжСЙ PNG ',
    '.swf'  =>  'Эбг ЭбЗФ Flash movie',
    '.doc'  =>  'жЛнЮЙ Microsoft Word',
    '.xls'  =>  'ЕЯУб Microsoft Excel ',
    '.pdf'  =>  'ГПжИн PDF document',
    '.rtf'  =>  'жЛнЮЙ RTF document',
    '.odt'  =>  'дХн OpenDocument Text',
    '.ods'  =>  'ФнК OpenDocument Spreadsheet',
    '.sxw'  =>  'дХн 1 OpenOffice.org 1.0 Text Document',
    '.sxc'  =>  'ФнК1  OpenOffice.org 1.0 Spreadsheet',
    '.wav'  =>  'ХжК WAV audio file',
    '.mp3'  =>  'ХжК MP3 audio file',
    '.ogg'  =>  'ХжК Ogg Vorbis audio file',
    '.wma'  =>  'ХжК Windows audio file',
    '.avi'  =>  'ЭПнж AVI video file',
    '.mpg'  =>  'ЭПнж MPEG video file',
    '.mpeg'  =>  'ЭПнж MPEG video file',
    '.mov'  =>  'ЭПнж QuickTime video file',
    '.wmv'  =>  'ЭПнж Windows video file',
    '.zip'  =>  'гЦЫжШ ZIP archive',
    '.rar'  =>  'гЦЫжШ RAR archive',
    '.gz'  =>  'гЦЫжШ gzip archive',
    '.txt'  =>  'дХн Text Document',
    ''  =>  '',
  ),
);
?>
