<?php
// ================================================
// SPAW PHP WYSIWYG editor control
// ================================================
// Finnish language file
// ================================================
// Developed: Alan Mendelevich, alan@solmetra.lt
// Copyright: Solmetra (c)2003 All rights reserved.
// Finnish translation: Teemu Joensuu, teemu.joensuu@saunalahti.fi
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.2.0, 2007-06-27
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'iso-8859-1';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'Leikkaa'
  ),
  'copy' => array(
    'title' => 'Kopioi'
  ),
  'paste' => array(
    'title' => 'Liitд'
  ),
  'undo' => array(
    'title' => 'Kumoa'
  ),
  'redo' => array(
    'title' => 'Tee uudelleen'
  ),
  'hyperlink' => array(
    'title' => 'Linkki'
  ),
	'image' => array(
    'title' => 'Kuvan nopea lisдys'
  ),
/*  'image_insert' => array(
    'title' => 'Lisдд kuva',
    'select' => 'Valitse',
    'cancel' => 'Peruuta',
    'library' => 'Kirjasto',
    'preview' => 'Esikatselu',
    'images' => 'Kuvat',
    'upload' => 'Lдhetд kuva palvelimelle',
    'upload_button' => 'Lдhetд',
    'error' => 'Virhe',
    'error_no_image' => 'Et valinnut kuvaa listalta.',
    'error_uploading' => 'Kuvan palvelimelle lдhetyksessд esiintyi virhe. Yritд myГ¶hemmin uudelleen.',
    'error_wrong_type' => 'Lдhettдmдsi tiedosto ei ollut tuettua tiedostomuotoa',
    'error_no_dir' => 'Kirjastoa ei ole fyysisesti olemassa.',
  ),
*/  'image_prop' => array(
    'title' => 'Kuvan ominaisuudet',
    'ok' => '   OK   ',
    'cancel' => 'Peruuta',
    'source' => 'Kuva',
    'alt' => 'Kuvaus (ALT)',
    'align' => 'Suhde tekstiin',
    'left' => 'kuva vasemmalla, teksti kiertдд',
    'right' => 'kuva oikealla, teksti kiertдд',
    'top' => 'teksti asettuu kuvan ylдreunaan',
    'middle' => 'teksti asettuu kuvan keskikork.',
    'bottom' => 'teksti asettuu kuvan alareunaan',
    'absmiddle' => 'absmiddle',
    'texttop' => 'texttop',
    'baseline' => 'baseline',
    'width' => 'Leveys',
    'height' => 'Korkeus',
    'border' => 'Reunus',
    'hspace' => 'Vaakas. tyhjд tila',
    'vspace' => 'Pystys. tyhjд tila',
    'dimensions' => 'Mitat', // <= new in 2.0.1
    'reset_dimensions' => 'Aseta alkuperдinen kuvakoko', // <= new in 2.0.1
    'title_attr' => 'Otsake', // <= new in 2.0.1
    'constrain_proportions' => 'Sдilytд kuvasuhde', // <= new in 2.0.1
    'error' => 'Virhe',
    'error_width_nan' => 'Leveyden arvo ei ole numero',
    'error_height_nan' => 'Korkeuden arvo ei ole numero',
    'error_border_nan' => 'Reunuksen arvo ei ole numero',
    'error_hspace_nan' => 'Vaakasuoran tyhjдn tilan arvo ei ole numero',
    'error_vspace_nan' => 'Pystysuoran tyhjдn tilan arvo ei ole numero',
  ),
  'flash_prop' => array(                // <= new in 2.0
    'title' => 'Flash-objektin liittдminen',
    'ok' => '   OK   ',
    'cancel' => 'Peruuta',
    'source' => 'Lдhde',
    'width' => 'Leveys',
    'height' => 'Korkeus',
    'error' => 'Virhe',
    'error_width_nan' => 'Leveyden arvo ei ole numero',
    'error_height_nan' => 'Korkeuden arvo ei ole numero',
  ),	
	
  'inserthorizontalrule' => array(
    'title' => 'Vaakaviiva'
  ),
  'table_create' => array(
    'title' => 'Luo taulukko'
  ),
  'table_prop' => array(
    'title' => 'Taulukon ominaisuudet',
    'ok' => '   OK   ',
    'cancel' => 'Peruuta',
    'rows' => 'Rivejд',
    'columns' => 'Sarakkeita',
    'width' => 'Leveys',
    'height' => 'Korkeus',
    'border' => 'Reunaviiva',
    'pixels' => 'kuvapistettд',
    'css_class' => 'Tyyli',
    'cellpadding' => 'Tekstin etдisyys solun reunasta',
    'cellspacing' => 'Solujen vдlinen tyhjд tila',
    'bg_color' => 'Taustavдri',
    'background' => 'Taustakuva',
    'error' => 'Virhe',
    'error_rows_nan' => 'Rivimддrдn arvo ei ole numero',
    'error_columns_nan' => 'Sarakemддrдn arvo ei ole numero',
    'error_width_nan' => 'Leveyden arvo ei ole numero',
    'error_height_nan' => 'Korkeuden arvo ei ole numero',
    'error_border_nan' => 'Reunuksen arvo ei ole numero',
    'error_cellpadding_nan' => 'Tekstin etдisyys solun reunasta -kentдn arvo ei ole numero',
    'error_cellspacing_nan' => 'Solujen vдlinen tyhjд tila -arvo ei ole numero',
  ),
  'table_cell_prop' => array(
    'title' => 'Taulukon solun ominaisuudet',
    'horizontal_align' => 'Tasaus vaakasuunnassa',
    'vertical_align' => 'Tasaus pystysuunnassa',
    'width' => 'Leveys',
    'height' => 'Korkeus',
    'css_class' => 'Tyyli',
    'no_wrap' => 'No wrap',
    'bg_color' => 'Taustavдri',
    'background' => 'Taustakuva',
    'ok' => '   OK   ',
    'cancel' => 'Peruuta',
    'justifyleft' => 'Vasen',
    'justifycenter' => 'Keskitд',
    'justifyright' => 'Oikea',
    'top' => 'YlГ¶s',
    'middle' => 'Keskelle',
    'bottom' => 'Alas',
    'baseline' => 'Baseline',
    'error' => 'Virhe',
    'error_width_nan' => 'Leveyden arvo ei ole numero',
    'error_height_nan' => 'Korkeuden arvo ei ole numero',
    
  ),
  'table_row_insert' => array(
    'title' => 'Lisдд rivi taulukkoon'
  ),
  'table_column_insert' => array(
    'title' => 'Lisдд sarake taulukkoon'
  ),
  'table_row_delete' => array(
    'title' => 'Poista rivi taulukosta'
  ),
  'table_column_delete' => array(
    'title' => 'Poista sarake taulukosta'
  ),
  'table_cell_merge_right' => array(
    'title' => 'Yhdistд oikealla puolella olevaan soluun'
  ),
  'table_cell_merge_down' => array(
    'title' => 'Yhdistд alapuolella olevaan soluun'
  ),
  'table_cell_split_horizontal' => array(
    'title' => 'Jaa solu vaakasuunnassa'
  ),
  'table_cell_split_vertical' => array(
    'title' => 'Jaa solu pystysuunnassa'
  ),
  'style' => array(
    'title' => 'Tyyli'
  ),
  'fontname' => array(
    'title' => 'Fontti'
  ),
  'fontsize' => array(
    'title' => 'Koko'
  ),
  'formatBlock' => array(
    'title' => 'Kappale'
  ),
  'bold' => array(
    'title' => 'Lihavoi'
  ),
  'italic' => array(
    'title' => 'Kursivoi'
  ),
  'underline' => array(
    'title' => 'Alleviivaa'
  ),
  'insertorderedlist' => array(
    'title' => 'Numeroitu luettelo'
  ),
  'insertunorderedlist' => array(
    'title' => 'Luettelomerkit'
  ),
  'indent' => array(
    'title' => 'Sisennд'
  ),
  'outdent' => array(
    'title' => 'Poista sisennystд'
  ),
  'justifyleft' => array(
    'title' => 'Tasaa vasempaan reunaan'
  ),
  'justifycenter' => array(
    'title' => 'Keskitд'
  ),
  'justifyright' => array(
    'title' => 'Tasaa oikeaan reunaan'
  ),
  'justifyfull' => array( // <== v.2.0 changed from justify
    'title' => 'Tasaa molemmat reunat'
  ),
  'fore_color' => array(
    'title' => 'Tekstin vдri'
  ),
  'bg_color' => array(
    'title' => 'Tekstin taustavдri'
  ),
  'design' => array(
    'title' => 'Vaihda sisдltцeditorin tekstinkдsittelyn kaltaiseen  WYSIWYG (design) -tilaan.'
  ),
  'html' => array(
    'title' => 'Vaihda HTML-kooditilaan'
  ),
  'colorpicker' => array(
    'title' => 'Vдrivalitsin',
    'ok' => '   OK   ',
    'cancel' => 'Peruuta',
  ),
	  'cleanup' => array(
    'title' => 'HTML-koodin puhdistus (poistaa tyylimддrittelyt)',
    'confirm' => 'Tдmд toiminto poistaa tдmдn sivun sisдllцstд kaikki tyylimддrittelyt, fonttimддrittelyt ja tarpeettomat komennot. Kaikki tekstin muotoilu tai osa muotoilusta voi kadota.',
    'ok' => '   OK   ',
    'cancel' => 'Peruuta',
  ),
  'toggle_borders' => array(
    'title' => 'Nдytд/Piilota reunuksettomien taulukkojen reunat',
  ),
  'hyperlink' => array(
    'title' => 'Linkki',
    'url' => 'Kohdeosoite (URL)',
    'name' => 'Nimi',
    'target' => 'Ikkuna, johon linkki avautuu',
    'title_attr' => 'Otsikko',
  	'a_type' => 'Linkin tyyppi',
  	'type_link' => 'Tavallinen linkki',
  	'type_linktoownpage' => 'Linkki omalle sivulle',
  	'type_linktofile' => 'Linkki tiedostoon palvelimella',
  	'type_anchor' => 'Ankkuri',
  	'type_link2anchor' => 'Linkki ankkuriin',
  	'anchors' => 'Ankkurit',
    'ok' => '   OK   ',
    'cancel' => 'Peruuta',
  ),
  'hyperlink_targets' => array(
  	'_self' => 'Sama ikkuna (_self)',
  	'_blank' => 'Uusi tyhjд ikkuna (_blank)',
  	'_top' => 'top frame (_top)',
  	'_parent' => 'parent frame (_parent)'
  ),
  'unlink' => array( // <=== new v.2.0
    'title' => 'Poista linkki'
  ),
  'table_row_prop' => array(
    'title' => 'Taulukon rivin ominaisuudet',
    'horizontal_align' => 'Tasaus vaakasuunnassa',
    'vertical_align' => 'Tasaus Pystysuunnassa',
    'css_class' => 'CSS tyyli',
    'no_wrap' => 'No wrap',
    'bg_color' => 'Taustavдri',
    'ok' => '   OK   ',
    'cancel' => 'Peruuta',
    'justifyleft' => 'Vasen',
    'justifycenter' => 'Keskitд',
    'justifyright' => 'Oikea',
    'top' => 'Ylцs',
    'middle' => 'Keskelle',
    'bottom' => 'Alas',
    'baseline' => 'Alareunaan',
  ),
  'symbols' => array(
    'title' => 'Erikoismerkit',
    'ok' => '   OK   ',
    'cancel' => 'Peruuta',
  ),
  'templates' => array(
    'title' => 'Ulkoasupohjat',
  ),
  'page_prop' => array(
    'title' => 'Sivun ominaisuudet',
    'title_tag' => 'Otsikko (Title)',
    'charset' => 'Charset',
    'background' => 'Taustakuva',
    'bgcolor' => 'Taustavдri',
    'text' => 'Tekstin vдri',
    'link' => 'Linkin vдri',
    'vlink' => 'Vieraillun linkin vдri',
    'alink' => 'Aktiivisen linkin vдri',
    'leftmargin' => 'Vasen reunus',
    'topmargin' => 'Ylдreunus',
    'css_class' => 'CSS luokka',
    'ok' => '   OK   ',
    'cancel' => 'Peruuta',
  ),
  'preview' => array(
    'title' => 'Esikatselu',
  ),
  'image_popup' => array(
    'title' => 'Ponnahduskuva',
  ),
  'zoom' => array(
    'title' => 'Zoomaa',
  ),
	'subscript' => array(
    'title' => 'Subscript',
  ),
  'superscript' => array(
    'title' => 'Superscript',
  ),

);
?>