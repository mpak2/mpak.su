<?php 
// ================================================
// SPAW File Manager plugin
// ================================================
// Lithuanian language file
// ================================================
// Developed: Saulius Okunevicius, saulius@solmetra.com
// Translated: Saulius Okunevicius, saulius@solmetra.com
// Copyright: Solmetra (c)2006 All rights reserved.
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.1.0, 2007-01-29
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'spawfm' => array(
    'title' => 'SPAW FailЕі tvarkyklД—',
    'error_reading_dir' => 'Klaida: nepavyko nuskaityti katalogo.',
    'error_upload_forbidden' => 'Klaida: failЕі atsiuntimas ЕЎiame kataloge uЕѕdraustas.',
    'error_upload_file_too_big' => 'Atsiuntimas nutrauktas: failas per didelis.',
    'error_upload_failed' => 'Failo atsiuntimas nepavyko.',
    'error_upload_file_incomplete' => 'AtsiЕіstas failas yra nepilnas, mД—ginkite dar kartД….',
    'error_bad_filetype' => 'Klaida: ЕЎio tipo failai neleidЕѕiami.',
    'error_max_filesize' => 'Maksimalus priimamЕі failЕі dydis:',
    'error_delete_forbidden' => 'Klaida: ЕЎiame kataloge trinti failЕі neleidЕѕiama.',
    'confirm_delete' => 'Ar tikrai norite iЕЎtrinti failД… "[*file*]"?',
    'error_delete_failed' => 'Klaida: failo iЕЎtrinti nepavyko. Galite neturД—ti teisiЕі tai atlikti.',
    'error_no_directory_available' => 'NarЕЎytinЕі katalogЕі nД—ra.',
    'download_file' => '[atsisiЕіsti failД…]',
    'error_chmod_uploaded_file' => 'Failo atsiuntimas sД—kmingas, taДЌiau jo teisiЕі pakeisti nepavyko.',
    'error_img_width_max' => 'Maksimalus leidЕѕiamas paveiksliuko plotis: [*MAXWIDTH*]px',
    'error_img_height_max' => 'Maksimalus leidЕѕiamas paveiksliuko aukЕЎtis: [*MAXHEIGHT*]px',
    'rename_text' => 'Nurodykite naujД… "[*FILE*]" pavadinimД…:',
    'error_rename_file_missing' => 'Pervadinti nepavyko - toks failas nerastas.',
    'error_rename_directories_forbidden' => 'Klaida: ЕЎiame kataloge pakatalogiЕі pervadinimas uЕѕdraustas.',
    'error_rename_forbidden' => 'Klaida: ЕЎiame kataloge failЕі pervadinimas uЕѕdraustas.',
    'error_rename_file_exists' => 'Klaida: "[*FILE*]" jau yra.',
    'error_rename_failed' => 'Klaida: pervadinti nepavyko. Galite neturД—ti teisiЕі tai atlikti.',
    'error_rename_extension_changed' => 'Klaida: failo iЕЎplД—timo keisti neleidЕѕiama!',
    'newdirectory_text' => 'Д®veskite katalogo pavadinimД…:',
    'error_create_directories_forbidden' => 'Klaida: kurti katalogus neleidЕѕiama',
    'error_create_directories_name_used' => 'Toks pavadinimas jau naudojamas, pasirinkite kitД….',
    'error_create_directories_failed' => 'Klaida: nepavyko sukurti katalogo. Galite neturД—ti teisiЕі tai atlikti.',
    'error_create_directories_name_invalid' => 'Е ie simboliai negali bЕ«ti naudojami pavadinime: / \\ : * ? " < > |',
    'confirmdeletedir_text' => 'Ar tikrai norite iЕЎtrinti katalogД… "[*DIR*]"?',
    'error_delete_subdirectories_forbidden' => 'Trinti katalogus neleidЕѕiama.',
    'error_delete_subdirectories_failed' => 'Katalogo iЕЎtrinti nepavyko, galite neturД—ti teisiЕі tai atlikti.',
    'error_delete_subdirectories_not_empty' => 'Katalogas netuЕЎДЌias.',
  ),
  'buttons' => array(
    'ok'        => ' Tinka ',
    'cancel'    => 'AtЕЎaukti',
    'view_list' => 'Rodyti kaip sД…raЕЎД…',
    'view_details' => 'Rodyti kaip detalЕі sД…raЕЎД…',
    'view_thumbs' => 'Rodyti paveiksliukus',
    'rename'    => 'Pervadinti...',
    'delete'    => 'IЕЎtrinti',
    'go_up'     => 'PerЕЎokti aukЕЎtyn',
    'upload'    =>  'AtsiЕіsti',
    'create_directory'  =>  'Naujas katalogas...',
  ),
  'file_details' => array(
    'name'  =>  'Pavadinimas',
    'type'  =>  'Tipas',
    'size'  =>  'Dydis',
    'date'  =>  'Pakeitimo data',
    'filetype_suffix'  =>  'failas',
    'img_dimensions'  =>  'IЕЎmatavimai',
    'file_folder'  =>  'Katalogas',
  ),
  'filetypes' => array(
    'any'       => 'Visi failai (*.*)',
    'images'    => 'Paveiksliukai',
    'flash'     => 'Flash filmukai',
    'documents' => 'Dokumentai',
    'audio'     => 'Garso ДЇraЕЎai',
    'video'     => 'Vaizdo ДЇraЕЎai',
    'archives'  => 'Archyvai',
    '.jpg'  =>  'JPG paveiksliukas',
    '.jpeg'  =>  'JPG paveiksliukas',
    '.gif'  =>  'GIF paveiksliukas',
    '.png'  =>  'PNG paveiksliukas',
    '.swf'  =>  'Flash filmukas',
    '.doc'  =>  'Microsoft Word dokumentas',
    '.xls'  =>  'Microsoft Excel dokumentas',
    '.pdf'  =>  'PDF dokumentas',
    '.rtf'  =>  'RTF dokumentas',
    '.odt'  =>  'OpenDocument tekstas',
    '.ods'  =>  'OpenDocument skaiДЌiuoklД—',
    '.sxw'  =>  'OpenOffice.org 1.0 tekstas',
    '.sxc'  =>  'OpenOffice.org 1.0 skaiДЌiuoklД—',
    '.wav'  =>  'WAV garso ДЇraЕЎas',
    '.mp3'  =>  'MP3 garso ДЇraЕЎas',
    '.ogg'  =>  'Ogg Vorbis garso ДЇraЕЎas',
    '.wma'  =>  'Windows garso ДЇraЕЎas',
    '.avi'  =>  'AVI vaizdo ДЇraЕЎas',
    '.mpg'  =>  'MPEG vaizdo ДЇraЕЎas',
    '.mpeg'  =>  'MPEG vaizdo ДЇraЕЎas',
    '.mov'  =>  'QuickTime vaizdo ДЇraЕЎas',
    '.wmv'  =>  'Windows vaizdo ДЇraЕЎas',
    '.zip'  =>  'ZIP archyvas',
    '.rar'  =>  'RAR archyvas',
    '.gz'  =>  'gzip archyvas',
    '.txt'  =>  'Tekstinis dokumentas',
    ''  =>  '',
  ),
);
?>