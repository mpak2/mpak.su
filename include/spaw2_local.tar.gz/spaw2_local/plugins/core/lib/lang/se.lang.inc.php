<?php 
// ================================================
// SPAW PHP WYSIWYG editor control
// ================================================
// Swedish language file
// ================================================
// Developed: Alan Mendelevich, alan@solmetra.lt
// Copyright: Solmetra (c)2003 All rights reserved.
// Swedish translation: Tomas Jogin - tomas@jogin.com
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.1.0, 2003-03-20
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'Klipp ut'
  ),
  'copy' => array(
    'title' => 'Kopiera'
  ),
  'paste' => array(
    'title' => 'Klistra in'
  ),
  'undo' => array(
    'title' => 'Г…ngra'
  ),
  'redo' => array(
    'title' => 'GГ¶r om'
  ),
  'hyperlink' => array(
    'title' => 'LГ¤nk'
  ),
  'image_insert' => array(
    'title' => 'Infoga bild',
    'select' => 'Infoga',
    'cancel' => 'Avbryt',
    'library' => 'Bildbibliotek',
    'preview' => 'FГ¶rhandsgranska',
    'images' => 'Bilder',
    'upload' => 'Ladda upp bild',
    'upload_button' => 'Ladda upp',
    'error' => 'Fel',
    'error_no_image' => 'VГ¤lj en bild',
    'error_uploading' => 'Ett fel uppstod vid fil-uppladdningen. Var god fГ¶rsГ¶k igen senare.',
    'error_wrong_type' => 'Fel bildtyp',
    'error_no_dir' => 'Bildbiblioteket finns inte',
  ),
  'image_prop' => array(
    'title' => 'Bildegenskaper',
    'ok' => '   OK   ',
    'cancel' => 'Avbryt',
    'source' => 'KГ¤lla',
    'alt' => 'Beskrivning',
    'align' => 'Justering',
    'justifyleft' => 'vГ¤nster',
    'justifyright' => 'hГ¶ger',
    'top' => 'toppen',
    'middle' => 'mitten',
    'bottom' => 'botten',
    'absmiddle' => 'absmiddle',
    'texttop' => 'texttop',
    'baseline' => 'baseline',
    'width' => 'Bredd',
    'height' => 'HГ¶jd',
    'border' => 'Kantlinje',
    'hspace' => 'Horisontell marginal',
    'vspace' => 'Vertikal marginal',
    'error' => 'Fel',
    'error_width_nan' => 'Bredd Г¤r inte ett nummer',
    'error_height_nan' => 'HГ¶jd Г¤r inte ett nummer',
    'error_border_nan' => 'Kantlinje Г¤r inte ett nummer',
    'error_hspace_nan' => 'Horisontell marginal Г¤r inte ett nummer',
    'error_vspace_nan' => 'Vertikal marginal Г¤r inte ett nummer',
  ),
  'inserthorizontalrule' => array(
    'title' => 'Horisontell linje'
  ),
  'table_create' => array(
    'title' => 'Skapa tabell'
  ),
  'table_prop' => array(
    'title' => 'Tabellegenskaper',
    'ok' => '   OK   ',
    'cancel' => 'Avbryt',
    'rows' => 'Rader',
    'columns' => 'Kolumner',
    'width' => 'Bredd',
    'height' => 'HГ¶jd',
    'border' => 'Kantlinje',
    'pixels' => 'pixlar',
    'cellpadding' => 'FГ¤ltmarginal',
    'cellspacing' => 'FГ¤ltavstГҐnd',
    'bg_color' => 'BakgrundsfГ¤rg',
    'error' => 'Fel',
    'error_rows_nan' => 'Rader Г¤r inte ett nummer',
    'error_columns_nan' => 'Kolumner Г¤r inte ett nummer',
    'error_width_nan' => 'Bredd Г¤r inte ett nummer',
    'error_height_nan' => 'HГ¶jd Г¤r inte ett nummer',
    'error_border_nan' => 'Kantlinje Г¤r inte ett nummer',
    'error_cellpadding_nan' => 'FГ¤ltmarginal Г¤r inte ett nummer',
    'error_cellspacing_nan' => 'FГ¤ltavstГҐnd Г¤r inte ett nummer',
  ),
  'table_cell_prop' => array(
    'title' => 'FГ¤ltegenskaper',
    'horizontal_align' => 'Horisontell justering',
    'vertical_align' => 'Vertikal justering',
    'width' => 'Bredd',
    'height' => 'HГ¶jd',
    'css_class' => 'CSS-klass',
    'no_wrap' => 'Ej automatisk radbrytning',
    'bg_color' => 'BakgrundsfГ¤rg',
    'ok' => '   OK   ',
    'cancel' => 'Avbryt',
    'justifyleft' => 'VГ¤nster',
    'justifycenter' => 'Mitten',
    'justifyright' => 'HГ¶ger',
    'top' => 'Toppen',
    'middle' => 'Mitten',
    'bottom' => 'Botten',
    'baseline' => 'Baslinje',
    'error' => 'Fel',
    'error_width_nan' => 'Bredd Г¤r inte ett nummer',
    'error_height_nan' => 'HГ¶jd Г¤r inte ett nummer',
  ),
  'table_row_insert' => array(
    'title' => 'Infoga rad'
  ),
  'table_column_insert' => array(
    'title' => 'Infoga kolumn'
  ),
  'table_row_delete' => array(
    'title' => 'Radera rad'
  ),
  'table_column_delete' => array(
    'title' => 'Radera kolumn'
  ),
  'table_cell_merge_right' => array(
    'title' => 'Sammanfoga till hГ¶ger'
  ),
  'table_cell_merge_down' => array(
    'title' => 'Sammanfoga nedГҐt'
  ),
  'table_cell_split_horizontal' => array(
    'title' => 'Dela fГ¤lt horisontellt'
  ),
  'table_cell_split_vertical' => array(
    'title' => 'Dela fГ¤lt vertikalt'
  ),
  'style' => array(
    'title' => 'Stilmall'
  ),
  'fontname' => array(
    'title' => 'Teckensnitt'
  ),
  'fontsize' => array(
    'title' => 'Storlek'
  ),
  'formatBlock' => array(
    'title' => 'Stycke'
  ),
  'bold' => array(
    'title' => 'Fetstil'
  ),
  'italic' => array(
    'title' => 'Kursiv'
  ),
  'underline' => array(
    'title' => 'Understruken'
  ),
  'insertorderedlist' => array(
    'title' => 'Sorterad lista'
  ),
  'insertunorderedlist' => array(
    'title' => 'Osorterad lista'
  ),
  'indent' => array(
    'title' => 'Indrag'
  ),
  'outdent' => array(
    'title' => 'Ta bort indrag'
  ),
  'justifyleft' => array(
    'title' => 'VГ¤nster'
  ),
  'justifycenter' => array(
    'title' => 'Mitten'
  ),
  'justifyright' => array(
    'title' => 'HГ¶ger'
  ),
  'fore_color' => array(
    'title' => 'FГ¶rgrundsfГ¤rg'
  ),
  'bg_color' => array(
    'title' => 'BakgrundsfГ¤rg'
  ),
  'design' => array(
    'title' => 'Byt till layout-lГ¤ge'
  ),
  'html' => array(
    'title' => 'Byt till HTML-lГ¤ge'
  ),
  'colorpicker' => array(
    'title' => 'FГ¤rgvГ¤ljare',
    'ok' => '   OK   ',
    'cancel' => 'Avbryt',
  ),
  'cleanup' => array(
    'title' => 'Rensa HTML',
    'confirm' => 'Detta rensar dokumentet frГҐn Г¶verflГ¶diga stilformateringar och uppmГ¤rkningar. Vissa eller alla stilformateringar kan fГ¶rsvinna.',
    'ok' => '   OK   ',
    'cancel' => 'Avbryt',
  ),
  'toggle_borders' => array(
    'title' => 'Visa/gГ¶m kantlinjer',
  ),
  'hyperlink' => array(
    'title' => 'Infoga lГ¤nk',
    'url' => 'Adress',
    'name' => 'Namn',
    'target' => 'FГ¶nster',
    'title_attr' => 'Titel',
    'ok' => '   OK   ',
    'cancel' => 'Avbryt',
  ),
  'table_row_prop' => array(
    'title' => 'Radegenskaper',
    'horizontal_align' => 'Horisontell justering',
    'vertical_align' => 'Vertikal justering',
    'css_class' => 'CSS-klass',
    'no_wrap' => 'Ej automatisk radbrytning',
    'bg_color' => 'BakgrundsfГ¤rg',
    'ok' => '   OK   ',
    'cancel' => 'Avbryt',
    'justifyleft' => 'VГ¤nster',
    'justifycenter' => 'Mitten',
    'justifyright' => 'HГ¶ger',
    'top' => 'Toppen',
    'middle' => 'Mitten',
    'bottom' => 'Botten',
    'baseline' => 'Baslinje',
  ),
  'symbols' => array(
    'title' => 'Speciella tecken',
    'ok' => '   OK   ',
    'cancel' => 'Avbryt',
  ),
  'templates' => array(
    'title' => 'Mallar',
  ),
  'page_prop' => array(
    'title' => 'Sidegenskaper',
    'title_tag' => 'Titel',
    'charset' => 'TeckenuppsГ¤ttning',
    'background' => 'Bakgrundsbild',
    'bgcolor' => 'BakgrundsfГ¤rg',
    'text' => 'TextfГ¤rg',
    'link' => 'LГ¤nkfГ¤rg',
    'vlink' => 'FГ¤rg pГҐ besГ¶kta lГ¤nkar',
    'alink' => 'FГ¤rg pГҐ markerade lГ¤nkar',
    'leftmargin' => 'VГ¤nstermarginal',
    'topmargin' => 'Topmarginal',
    'css_class' => 'CSS-klass',
    'ok' => '   OK   ',
    'cancel' => 'Avbryt',
  ),
  'preview' => array(
    'title' => 'FГ¶rhandsgranska',
  ),
  'image_popup' => array(
    'title' => 'Bild-popup',
  ),
  'zoom' => array(
    'title' => 'Zoom',
  ),
);
?>