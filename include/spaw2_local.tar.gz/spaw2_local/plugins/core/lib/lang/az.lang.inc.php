<?php 
// ================================================
// SPAW PHP WYSIWYG editor control
// ================================================
// Azerbaijani language file
// ================================================
// Developed: Alan Mendelevich, alan@solmetra.lt
// Translated: Shamil Mehdiyev, supervisor@box.az 
// Copyright: Solmetra (c)2003 All rights reserved.
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.1.0, 2003-03-20
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'KЙ™s'
  ),
  'copy' => array(
    'title' => 'Kopyala'
  ),
  'paste' => array(
    'title' => 'YapД±ЕџdД±r'
  ),
  'undo' => array(
    'title' => 'Geri al'
  ),
  'redo' => array(
    'title' => 'TЙ™krarla'
  ),
  'image_insert' => array(
    'title' => 'ЕћЙ™kil Й™lavЙ™ et',
    'select' => 'SeГ§',
	'delete' => 'Sil', // new 1.0.5
    'cancel' => 'LЙ™Дџv et',
    'library' => 'Kitabxana',
    'preview' => 'GГ¶rГјnГјЕџ',
    'images' => 'ЕћЙ™killЙ™r',
    'upload' => 'ЕћЙ™kil yГјklЙ™',
    'upload_button' => 'YГјklЙ™',
    'error' => 'XЙ™ta',
    'error_no_image' => 'ЕћЙ™kil seГ§in',
    'error_uploading' => 'FaylД±n yГјklЙ™nmЙ™si zamanД± xЙ™ta baЕџ verdi. ZЙ™hmЙ™t olmasa bir az sonra tЙ™krar yoxlayД±n',
    'error_wrong_type' => 'DГјzgun olmayan ЕџЙ™kil formatД±',
    'error_no_dir' => 'Kitabxana fiziki olaraq mГ¶vcud deyil',
	'error_cant_delete' => 'SilmЙ™ mГјvЙ™ffЙ™qiyyЙ™tsiz oldu', // new 1.0.5
  ),
  'image_prop' => array(
    'title' => 'ЕћЙ™kil xГјsusiyyЙ™tlЙ™ri',
    'ok' => '   OK   ',
    'cancel' => 'LЙ™Дџv et',
    'source' => 'MЙ™nbЙ™',
    'alt' => 'Alternativ mЙ™tn',
    'align' => 'YerlЙ™ЕџmЙ™',
    'justifyleft' => 'sol',
    'justifyright' => 'saДџ',
    'top' => 'Гјst',
    'middle' => 'orta',
    'bottom' => 'alt',
    'absmiddle' => 'tЙ™n orta',
    'texttop' => 'mЙ™tn yuxarД±da',
    'baseline' => 'altxЙ™tt',
    'width' => 'Uzunluq',
    'height' => 'HГјndГјrlГјk',
    'border' => 'SЙ™rhЙ™d',
    'hspace' => 'Hor. boЕџluq',
    'vspace' => 'Ећaq. boЕџluq',
    'error' => 'XЙ™ta',
    'error_width_nan' => 'Uzunluq rЙ™qЙ™m deyil',
    'error_height_nan' => 'HГјndГјrlГјk rЙ™qЙ™m deyil',
    'error_border_nan' => 'SЙ™rhЙ™d rЙ™qЙ™m deyil',
    'error_hspace_nan' => 'Horizontal boЕџluq rЙ™qЙ™m deyil',
    'error_vspace_nan' => 'Ећaquli boЕџluq rЙ™qЙ™m deyil',
  ),
  'inserthorizontalrule' => array(
    'title' => 'Horizontal xЙ™tt'
  ),
  'table_create' => array(
    'title' => 'CЙ™dvЙ™l dГјzЙ™lt'
  ),
  'table_prop' => array(
    'title' => 'CЙ™dvЙ™l xГјsusiyyЙ™tlЙ™ri',
    'ok' => '   OK   ',
    'cancel' => 'LЙ™Дџv et',
    'rows' => 'SЙ™tir',
    'columns' => 'SГјtun',
    'css_class' => 'CSS sinifi', // <=== new 1.0.6
    'width' => 'Uzunluq',
    'height' => 'HГјndГјrlГјk',
    'border' => 'SЙ™rhЙ™d',
    'pixels' => 'piksel',
    'cellpadding' => 'HГјceyrЙ™dЙ™n uzaqlД±q',
    'cellspacing' => 'HГјceyrЙ™ uzaqlД±ДџД±',
    'bg_color' => 'Arxa fon rЙ™ngi',
    'background' => 'Arxa fon ЕџЙ™kli', // <=== new 1.0.6
    'error' => 'XЙ™ta',
    'error_rows_nan' => 'SЙ™tir rЙ™qЙ™m deyil',
    'error_columns_nan' => 'SГјtun rЙ™qЙ™m deyil',
    'error_width_nan' => 'Uzunluq rЙ™qЙ™m deyil',
    'error_height_nan' => 'HГјndГјrlГјk rЙ™qЙ™m deyil',
    'error_border_nan' => 'SЙ™rhЙ™d rЙ™qЙ™m deyil',
    'error_cellpadding_nan' => 'HГјceyrЙ™dЙ™n uzaqlД±q rЙ™qЙ™m deyil',
    'error_cellspacing_nan' => 'HГјceyrЙ™ uzaqlД±ДџД± rЙ™qЙ™m deyil',
  ),
  'table_cell_prop' => array(
    'title' => 'HГјceyrЙ™ xГјsusiyyЙ™tlЙ™ri',
    'horizontal_align' => 'Horizontal yerlЙ™ЕџmЙ™',
    'vertical_align' => 'Ећaquli yerlЙ™ЕџmЙ™',
    'width' => 'Uzunluq',
    'height' => 'HГјndГјrlГјk',
    'css_class' => 'CSS sinifi',
    'no_wrap' => 'YД±ДџД±lma olmasД±n',
    'bg_color' => 'Arxa fon rЙ™ngi',
    'background' => 'Arxa fon ЕџЙ™kli', // <=== new 1.0.6
    'ok' => '   OK   ',
    'cancel' => 'LЙ™Дџv et',
    'justifyleft' => 'Sol',
    'justifycenter' => 'MЙ™rkЙ™z',
    'justifyright' => 'SaДџ',
    'top' => 'Гњst',
    'middle' => 'Orta',
    'bottom' => 'Alt',
    'baseline' => 'AltxЙ™tt',
    'error' => 'XЙ™ta',
    'error_width_nan' => 'Uzunluq rЙ™qЙ™m deyil',
    'error_height_nan' => 'HГјndГјrlГјk rЙ™qЙ™m deyil',
  ),
  'table_row_insert' => array(
    'title' => 'SЙ™tir Й™lavЙ™ et'
  ),
  'table_column_insert' => array(
    'title' => 'SГјtun Й™lavЙ™ et'
  ),
  'table_row_delete' => array(
    'title' => 'SЙ™tir sil'
  ),
  'table_column_delete' => array(
    'title' => 'SГјtun sil'
  ),
  'table_cell_merge_right' => array(
    'title' => 'SaДџla birlЙ™ЕџmЙ™'
  ),
  'table_cell_merge_down' => array(
    'title' => 'AЕџaДџД±yla birlЙ™ЕџmЙ™'
  ),
  'table_cell_split_horizontal' => array(
    'title' => 'HГјceyrЙ™ni horizontal bГ¶l'
  ),
  'table_cell_split_vertical' => array(
    'title' => 'HГјceyrЙ™ni Еџaquli bГ¶l'
  ),
  'style' => array(
    'title' => 'Stil'
  ),
  'codesnippet' => array(
    'title' => 'Ећablon'
  ),
  'fontname' => array(
    'title' => 'Font'
  ),
  'fontsize' => array(
    'title' => 'Г–lГ§Гј'
  ),
  'formatBlock' => array(
    'title' => 'Paraqraf'
  ),
  'bold' => array(
    'title' => 'QalД±n'
  ),
  'italic' => array(
    'title' => 'ЖЏyri'
  ),
  'underline' => array(
    'title' => 'AltxЙ™tli'
  ),
  'insertorderedlist' => array(
    'title' => 'NГ¶mrЙ™li siyahД±'
  ),
  'insertunorderedlist' => array(
    'title' => 'Muncuqlu siyahД±'
  ),
  'indent' => array(
    'title' => 'Abzas Й™lavЙ™ et'
  ),
  'outdent' => array(
    'title' => 'Abzas sil'
  ),
  'justifyleft' => array(
    'title' => 'Sol'
  ),
  'justifycenter' => array(
    'title' => 'MЙ™rkЙ™z'
  ),
  'justifyright' => array(
    'title' => 'SaДџ'
  ),
  'fore_color' => array(
    'title' => 'YazД± rЙ™ngi'
  ),
  'bg_color' => array(
    'title' => 'Arxa plan rЙ™ngi'
  ),
  'design' => array(
    'title' => 'WYSIWYG (dizayn) moduna keГ§in'
  ),
  'html' => array(
    'title' => 'HTML (kod) moduna keГ§in'
  ),
  'colorpicker' => array(
    'title' => 'RЙ™ng seГ§Й™n',
    'ok' => '   OK   ',
    'cancel' => 'LЙ™Дџv et',
  ),
  'cleanup' => array(
    'title' => 'HTML tЙ™mizlЙ™mЙ™si (stillЙ™ri sil)',
    'confirm' => 'Bu Й™mЙ™liyyat icra edilЙ™rsЙ™ cari mЙ™zmundakД± bГјtГјn stillЙ™r, fontlar vЙ™ tag-lЙ™r silinЙ™cЙ™kdir. FormatlaЕџdД±rmanД±zД±n bir qismi vЙ™ ya hamД±sД± silinЙ™ bilЙ™r.',
    'ok' => '   OK   ',
    'cancel' => 'LЙ™Дџv et',
  ),
  'toggle_borders' => array(
    'title' => 'SЙ™rhЙ™dlЙ™ri dЙ™yiЕџ',
  ),
  'hyperlink' => array(
    'title' => 'Hiperlink',
    'url' => 'URL',
    'name' => 'Ad',
    'target' => 'HЙ™dЙ™f',
    'title_attr' => 'BaЕџlД±q',
	'a_type' => 'Tip', // <=== new 1.0.6
	'type_link' => 'Link', // <=== new 1.0.6
	'type_anchor' => 'LГ¶vbЙ™r', // <=== new 1.0.6
	'type_link2anchor' => 'LГ¶vbЙ™rЙ™ link', // <=== new 1.0.6
	'anchors' => 'LГ¶vbЙ™rlЙ™r', // <=== new 1.0.6
    'ok' => '   OK   ',
    'cancel' => 'LЙ™Дџv et',
  ),
  'hyperlink_targets' => array( // <=== new 1.0.5
  	'_self' => 'eyni Г§Й™rГ§ivЙ™ (_self)',
	'_blank' => 'yeni boЕџ pЙ™ncЙ™rЙ™ (_blank)',
	'_top' => 'yuxarД± Г§Й™rГ§ivЙ™(_top)',
	'_parent' => 'valideyn Г§Й™rГ§ivЙ™ (_parent)'
  ),
  'table_row_prop' => array(
    'title' => 'SЙ™tir xГјsusiyyЙ™tlЙ™ri',
    'horizontal_align' => 'Horizontal yerlЙ™ЕџmЙ™',
    'vertical_align' => 'Ећaquli yerlЙ™ЕџmЙ™',
    'css_class' => 'CSS sinifi',
    'no_wrap' => 'YД±ДџД±lma olasД±n',
    'bg_color' => 'Arxa fon rЙ™ngi',
    'ok' => '   OK   ',
    'cancel' => 'LЙ™Дџv et',
    'justifyleft' => 'Sol',
    'justifycenter' => 'MЙ™rkЙ™z',
    'justifyright' => 'SaДџ',
    'top' => 'Гњst',
    'middle' => 'Orta',
    'bottom' => 'Alt',
    'baseline' => 'AltxЙ™tt',
  ),
  'symbols' => array(
    'title' => 'XГјsusi simvollar',
    'ok' => '   OK   ',
    'cancel' => 'LЙ™Дџv et',
  ),
  'templates' => array(
    'title' => 'Ећablonlar',
  ),
  'page_prop' => array(
    'title' => 'SЙ™hifЙ™ xГјsusiyyЙ™tlЙ™ri',
    'title_tag' => 'BaЕџlД±q',
    'charset' => 'Charset',
    'background' => 'Arxa fon ЕџЙ™kli',
    'bgcolor' => 'Arxa fon rЙ™ngi',
    'text' => 'MЙ™zmun rЙ™ngi',
    'link' => 'Link rЙ™ngi',
    'vlink' => 'AГ§Д±lmД±Еџ linkin rЙ™ngi',
    'alink' => 'Aktiv linkin rЙ™ngi',
    'leftmargin' => 'Sol boЕџluq',
    'topmargin' => 'YuxarД± boЕџluq',
    'css_class' => 'CSS sinifi',
    'ok' => '   OK   ',
    'cancel' => 'LЙ™Дџv et',
  ),
  'preview' => array(
    'title' => 'GГ¶rГјnГјЕџ',
  ),
  'image_popup' => array(
    'title' => 'ЕћЙ™kil (popup)',
  ),
  'zoom' => array(
    'title' => 'BГ¶yГјt',
  ),
  'subscript' => array( // <=== new 1.0.7
    'title' => 'AltyazД±',
  ),
  'superscript' => array( // <=== new 1.0.7
    'title' => 'ГњstyazД±',
  ),
);
?>