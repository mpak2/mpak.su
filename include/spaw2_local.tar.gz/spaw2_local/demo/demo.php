<?php
include("../spaw.inc.php");
$spaw1 = new SpawEditor("spaw1");
?>
<form method="post">
<?php $spaw1->show(); ?>
</form>

