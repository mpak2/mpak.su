<?php
// ================================================
// SPAW File Manager plugin
// ================================================
// English language file
// ================================================
// Developed: Saulius Okunevicius, saulius@solmetra.com
// Copyright: Solmetra (c)2006 All rights reserved.
// Translator: Stoyan Dimitrov, stoyanster@gmail.com, 04.12.2007
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.1.0, 2006-11-20
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array (
	'spawfm' => array (
		'title' => 'SPAW Р¤Р°Р№Р»РѕРІ РњР°РЅРёРїСѓР»Р°С‚РѕСЂ',
		'error_reading_dir' => 'Р“СЂРµС€РєР°: РЅРµРІСЉР·РјРѕР¶РЅРѕ С‡РµС‚РµРЅРµС‚Рѕ РѕС‚ РїР°РїРєР°С‚Р°.',
		'error_upload_forbidden' => 'Р“СЂРµС€РєР°: Р