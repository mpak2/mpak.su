<?php 
// ================================================
// SPAW File Manager plugin
// ================================================
// English language file
// ================================================
// Developed: Saulius Okunevicius, saulius@solmetra.com
// Translated: Szentgyцrgyi Jбnos, info@dynamicart.hu
// Copyright: Solmetra (c)2006 All rights reserved.
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.1.0, 2006-11-20
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'iso-8859-2';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'spawfm' => array(
    'title' => 'SPAW Fбjl menedzser',
    'error_reading_dir' => 'Hiba: Nem tudom olvasni a kцnyvtбr tartalmбt.',
    'error_upload_forbidden' => 'Hiba: Fбjl feltцltйs nem engedйjezett ebbe a mappбba.',
    'error_upload_file_too_big' => 'Feltцltйsi hiba: Fбjl tъl nagy.',
    'error_upload_failed' => 'Fбjl feltцltйs nem sikerьlt.',
    'error_upload_file_incomplete' => 'Fбjl feltцltйs nem fejezхdцtt be, prуbбld ъjra.',
    'error_bad_filetype' => 'Hiba: Feltцltendх fбjl tipusa nem engedйjezett.',
    'error_max_filesize' => 'A legnagyobb feltцltendх fбjl mйrete:',
    'error_delete_forbidden' => 'Hiba: Ebben a mappбban nincs engedйjezve a tцrlйs.',
    'confirm_delete' => 'Biztosan akarod tцrцlni ezeket a fбjlokat "[*file*]"?',
    'error_delete_failed' => 'Hiba: Fбjlt nem tudtam tцrцlni.',
    'error_no_directory_available' => 'Nincs elйrhetх tallуzhatу mappa.',
    'download_file' => '[Fбjl letцltйs]',
    'error_chmod_uploaded_file' => 'Fбjl feltцltйs sikeres, de a chmod\'ing nem sikerьlt.',
    'error_img_width_max' => 'A legnagyobb megengedett kйpszйlessйg: [*MAXWIDTH*]px',
    'error_img_height_max' => 'A legnagyobb megengedett kйpmagassбg: [*MAXHEIGHT*]px',
    'rename_text' => 'Kйrem az ъj nevet "[*FILE*]":',
    'error_rename_file_missing' => 'Бtnevezйs nem sikerьlt - nem talбlom a fбjlt.',
    'error_rename_directories_forbidden' => 'Hiba: Mappa бtnevezйs nem engedйjezett ebben a mappбban.',
    'error_rename_forbidden' => 'Hiba: Fбjl бtnevezeйs nem megengedett ebben a mappбban.',
    'error_rename_file_exists' => 'Hiba: "[*FILE*]" mбr lйtezik.',
    'error_rename_failed' => 'Hiba: Бtnevezйs nem sikerьlt. Nincs hozzб elegendх jog.',
    'error_rename_extension_changed' => 'Hiba: A fбjl kiterjesztйs mуdosнtбsa nem megengedett!',
    'newdirectory_text' => 'Kйrem a mappa nevйt:',
    'error_create_directories_forbidden' => 'Hiba: Mappa kйszнtйs elutasнtva',
    'error_create_directories_name_used' => 'Ezt a nevet mбr hasznбljбk, kйrlek prуbбlj mбsikat.',
    'error_create_directories_failed' => 'Hiba: Mappбt nem tudtam mlйtrehozni. Nincs elegendх jogod.',
    'error_create_directories_name_invalid' => 'Ezeket a karaktereket nem hasznбlhatod mappanйvben: / \\ : * ? " < > |',
    'confirmdeletedir_text' => 'Biztos tцrцlni akarod a mappбt "[*DIR*]"?',
    'error_delete_subdirectories_forbidden' => 'Mappa tцrlйse elutasнtva.',
    'error_delete_subdirectories_failed' => 'Mappбt nem tudtam tцrцlni. Nincs elegendх jog.',
    'error_delete_subdirectories_not_empty' => 'Mappa nem ьres.',
  ),
  'buttons' => array(
    'ok'        => '  OK  ',
    'cancel'    => 'Mйgsem',
    'view_list' => 'Nйzet: lista',
    'view_details' => 'Nйzet: rйszletek',
    'view_thumbs' => 'Nйzet: kiskйpek',
    'rename'    => 'Бtnevezйs',
    'delete'    => 'Tцrlйs',
    'go_up'     => 'Fel',
    'upload'    =>  'Feltцltйs',
    ''  =>  '',
  ),
  'file_details' => array(
    'name'  =>  'Nйv',
    'type'  =>  'Tipus',
    'size'  =>  'Mйret',
    'date'  =>  'Dбtum',
    'filetype_suffix'  =>  'Fбjl',
    'img_dimensions'  =>  'Kйp mйretei',
    ''  =>  '',
    ''  =>  '',
  ),
  'filetypes' => array(
    'any'       => 'Minden fбjl (*.*)',
    'images'    => 'Kйp fбjlok',
    'flash'     => 'Flash mozik',
    'documents' => 'Dokumentumok',
    'audio'     => 'Zenei fбjlok',
    'video'     => 'Videу fбjlok',
    'archives'  => 'Arhнv fбjlok',
    '.jpg'  =>  'JPG kйp fбjl',
    '.jpeg'  =>  'JPG kйp fбjl',
    '.gif'  =>  'GIF kйp fбjl',
    '.png'  =>  'PNG kйp fбjl',
    '.swf'  =>  'Flash mozi',
    '.doc'  =>  'Microsoft Word dokumentum',
    '.xls'  =>  'Microsoft Excel dokumentum',
    '.pdf'  =>  'PDF dokumentum',
    '.rtf'  =>  'RTF dokumentum',
    '.odt'  =>  'OpenDocument szцveg',
    '.ods'  =>  'OpenDocument tбblбzat',
    '.sxw'  =>  'OpenOffice.org 1.0 szцveges dokumentum',
    '.sxc'  =>  'OpenOffice.org 1.0 tбblбzat',
    '.wav'  =>  'WAV hang fбjl',
    '.mp3'  =>  'MP3 hang fбjl',
    '.ogg'  =>  'Ogg Vorbis hang fбjl',
    '.wma'  =>  'Windows hang fбjl',
    '.avi'  =>  'AVI videу fбjl',
    '.mpg'  =>  'MPEG videу fбjl',
    '.mpeg'  =>  'MPEG videу fбjl',
    '.mov'  =>  'QuickTime videу fбjl',
    '.wmv'  =>  'Windows videу fбjl',
    '.zip'  =>  'ZIP tцmцrнtйs',
    '.rar'  =>  'RAR tцmцrнtйs',
    '.gz'  =>  'gzip tцmцrнtйs',
    '.txt'  =>  'Szцveges dokumentum',
    ''  =>  '',
  ),
);
?>
