<?php
$items = array
(
  new SpawTbButton('custombutton', 'my_button', 'isMyButtonEnabled', '', 'myButtonClick'),
);
?>
