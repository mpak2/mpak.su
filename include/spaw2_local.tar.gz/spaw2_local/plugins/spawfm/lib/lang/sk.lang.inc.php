<?php 
// ================================================
// SPAW File Manager plugin
// ================================================
// Slovak language file
// ================================================
// Developed: Saulius Okunevicius, saulius@solmetra.com
// Copyright: Solmetra (c)2006 All rights reserved.
// Slovak translation: Martin Е vec
//                     shuter@vadium.sk
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.2.0, 2008-02-26
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'spawfm' => array(
    'title' => 'SPAW ManaЕѕГ©r sГєborov',
    'error_reading_dir' => 'Chyba: nemГґЕѕem preДЌГ­taЕҐ obsah adresГЎra.',
    'error_upload_forbidden' => 'Chyba: upload sГєboru nieje v tomto adresГЎri povolenГЅ.',
    'error_upload_file_too_big' => 'Upload sa nepodaril: sГєbor je prГ­liЕЎ veДѕkГЅ.',
    'error_upload_failed' => 'Upload sГєboru sa nepodaril.',
    'error_upload_file_incomplete' => 'UploadovanГЅ sГєbor nieje kompletnГЅ, skГєste to znova.',
    'error_bad_filetype' => 'Chyba: sГєbory tohoto typu nie sГє povolenГ©.',
    'error_max_filesize' => 'Max. prГ­pustnГЎ veДѕkosЕҐ uploadovanГ©ho sГєboru:',
    'error_delete_forbidden' => 'Chyba: mazanie sГєborov v adresГЎri nieje povolenГ©.',
    'confirm_delete' => 'Naozaj chcete vymazaЕҐ sГєbor "[*file*]"?',
    'error_delete_failed' => 'Chyba: sГєbor nemГґЕѕe byЕҐ zmazanГЅ. NemГЎte oprГЎvnenie k tejto operГЎcii.',
    'error_no_directory_available' => 'Neboli nГЎjdenГ© Еѕiadne adresГЎre.',
    'download_file' => '[download file]',
    'error_chmod_uploaded_file' => 'Upload sГєboru sa podaril, ale zmena atribГєtov sГєboru nebola ГєspeЕЎnГЎ.',
    'error_img_width_max' => 'MaximГЎlna povolenГЎ ЕЎГ­rka obrГЎzka: [*MAXWIDTH*]px',
    'error_img_height_max' => 'MaximГЎlna povolenГЎ vГЅЕЎka obrГЎzka: [*MAXHEIGHT*]px',
    'rename_text' => 'Zadajte novГ© meno pre sГєbor "[*FILE*]":',
    'error_rename_file_missing' => 'Premenovanie sa nepodarilo - sГєbor nebol nГЎjdenГЅ.',
    'error_rename_directories_forbidden' => 'Chyba: premenovanie tohoto adresГЎra nieje povolenГ©.',
    'error_rename_forbidden' => 'Chyba: v tomto adresГЎri nieje povolenГ© premenovГЎvaЕҐ sГєbory.',
    'error_rename_file_exists' => 'Chyba: "[*FILE*]" uЕѕ existuje.',
    'error_rename_failed' => 'Chyba: premenovanie sa nepodarilo. NemГЎte potrebnГ© prГЎva.',
    'error_rename_extension_changed' => 'Chyba: nieje povolenГ© meniЕҐ prГ­ponu sГєborov!',
    'newdirectory_text' => 'Zadajte meno adresГЎra:',
    'error_create_directories_forbidden' => 'Chyba: vytvГЎranie adresГЎrov je zakГЎzanГ©',
    'error_create_directories_name_used' => 'Tento nГЎzov bol uЕѕ pouЕѕitГЅ, skГєste prosГ­m pouЕѕiЕҐ inГЅ.',
    'error_create_directories_failed' => 'Chyba: adresГЎr nemohol byЕҐ vytvorenГЅ. NemГЎte potrebnГ© prГЎva.',
    'error_create_directories_name_invalid' => 'Tieto znaky nesmГє byЕҐ pouЕѕitГ© v nГЎzve adresГЎra: / \\ : * ? " < > |',
    'confirmdeletedir_text' => 'Naozaj chcete odstrГЎniЕҐ adresГЎr "[*DIR*]"?',
    'error_delete_subdirectories_forbidden' => 'OdstrГЎnenie adresГЎra nieje povolenГ©.',
    'error_delete_subdirectories_failed' => 'AdresГЎr nemohol byЕҐ odstrГЎnenГЅ. NemГЎte potrebnГ© prГЎva.',
    'error_delete_subdirectories_not_empty' => 'AdresГЎr nieje prГЎzdny.',
  ),
  'buttons' => array(
    'ok'        => '  OK  ',
    'cancel'    => 'ZruЕЎiЕҐ',
    'view_list' => 'Zobrazenie: zoznam',
    'view_details' => 'Zobrazenie: detaily',
    'view_thumbs' => 'Zobrazenie: nГЎhДѕady',
    'rename'    => 'PremenovaЕҐ...',
    'delete'    => 'VymazaЕҐ',
    'go_up'     => 'O ГєroveЕ€ vyЕЎЕЎie',
    'upload'    =>  'Upload',
    'create_directory'  =>  'VytvoriЕҐ novГЅ adresГЎr...',
  ),
  'file_details' => array(
    'name'  =>  'meno',
    'type'  =>  'Typ',
    'size'  =>  'VeДѕkosЕҐ',
    'date'  =>  'DГЎtum zmeny',
    'filetype_suffix'  =>  'sГєbor',
    'img_dimensions'  =>  'Rozmery',
    'file_folder'  =>  'PrieДЌinok sГєborov',
  ),
  'filetypes' => array(
    'any'       => 'VЕЎetky sГєbory (*.*)',
    'images'    => 'ObrГЎzky',
    'flash'     => 'Flash',
    'documents' => 'TextovГ© sГєbory',
    'audio'     => 'ZvukovГ© sГєbory',
    'video'     => 'Video sГєbory',
    'archГ­ves'  => 'KomprimovanГ© sГєbory',
    '.jpg'  =>  'JPG obrГЎzok',
    '.jpeg' =>  'JPG obrГЎzok',
    '.gif'  =>  'GIF obrГЎzok',
    '.png'  =>  'PNG obrГЎzok',
    '.swf'  =>  'Flash',
    '.doc'  =>  'Microsoft Word dokument',
    '.xls'  =>  'Microsoft Excel dokument',
    '.pdf'  =>  'PDF dokument',
    '.rtf'  =>  'RTF dokument',
    '.odt'  =>  'OpenDocument Text',
    '.ods'  =>  'OpenDocument Spreadsheet',
    '.sxw'  =>  'OpenOffice.org 1.0 Text Dokument',
    '.sxc'  =>  'OpenOffice.org 1.0 Spreadsheet',
    '.wav'  =>  'WAV audio',
    '.mp3'  =>  'MP3 audio',
    '.ogg'  =>  'Ogg Vorbis audio',
    '.wma'  =>  'Windows audio',
    '.avi'  =>  'AVI video',
    '.mpg'  =>  'MPEG video',
    '.mpeg' =>  'MPEG video',
    '.mov'  =>  'QuickTime video',
    '.wmv'  =>  'Windows video',
    '.zip'  =>  'ZIP archГ­v',
    '.rar'  =>  'RAR archГ­v',
    '.gz'   =>  'gzip archГ­v',
    '.txt'  =>  'TextovГЅ dokument',
    ''  =>  '',
  ),
);
?>
