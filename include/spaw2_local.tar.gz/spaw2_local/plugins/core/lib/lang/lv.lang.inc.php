<?php 
// ================================================
// SPAW PHP WYSIWYG editor control
// ================================================
// Latvian language file
// ================================================
// Developed: JДЃnis GrДЃvitДЃs, sun@sveiks.lv
// Copyright: Solmetra (c)2003 All rights reserved.
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'Izgriezt'
  ),
  'copy' => array(
    'title' => 'KopД“t'
  ),
  'paste' => array(
    'title' => 'Ielikt'
  ),
  'undo' => array(
    'title' => 'Atcelt'
  ),
  'redo' => array(
    'title' => 'AtkДЃrtot'
  ),
  'image_insert' => array(
    'title' => 'Ielikt attД“loЕЎanu',
    'select' => 'Ielikt',
	'delete' => 'NodzД“st', // new 1.0.5
    'cancel' => 'Atcelt',
    'library' => 'BibliotД“ka',
    'preview' => 'CaurskatД«ЕЎana',
    'images' => 'AttД“loЕЎanas',
    'upload' => 'Piekraut attД“loЕЎanu',
    'upload_button' => 'Piekraut',
    'error' => 'KДјЕ«da',
    'error_no_image' => 'IzvД“laties attД“loЕЎanu',
    'error_uploading' => 'IelДЃdes laikДЃ notika kДјЕ«da. IemД“ДЈiniet vД“lreiz.',
    'error_wrong_type' => 'NekДЃrtna attД“loЕЎanas tips',
    'error_no_dir' => 'BibliotД“ka neeksistД“',
	'error_cant_delete' => 'NodzД“st neizdevДЃs', // new 1.0.5
  ),
  'image_prop' => array(
    'title' => 'AttД“loЕЎanas parametri',
    'ok' => 'GATAVS',
    'cancel' => 'Atcelt',
    'source' => 'Avots',
    'alt' => 'ДЄss apraksts',
    'align' => 'IzlД«dzinДЃЕЎana',
    'justifyleft' => 'pa kreisi (left)',
    'justifyright' => 'pa labi (right)',
    'top' => 'no augЕЎas (top)',
    'middle' => 'centrДЃ (middle)',
    'bottom' => 'no lejas (bottom)',
    'absmiddle' => 'absolЕ«ts centrs (absmiddle)',
    'texttop' => 'no augЕЎas (texttop)',
    'baseline' => 'no lejas (baseline)',
    'width' => 'Platums',
    'height' => 'Augstums',
    'border' => 'RДЃmД«tis',
    'hspace' => 'Hor. lauki',
    'vspace' => 'Vert. lauki',
    'error' => 'KДјЕ«da',
    'error_width_nan' => 'Platums nav skaitlis',
    'error_height_nan' => 'Augstums nav skaitlis',
    'error_border_nan' => 'RДЃmД«tis nav skaitlis',
    'error_hspace_nan' => 'HorizontДЃli lauki nav skaitlis',
    'error_vspace_nan' => 'VertikДЃli lauki nav skaitlis',
  ),
  'inserthorizontalrule' => array(
    'title' => 'HorizontДЃla lД«nija'
  ),
  'table_create' => array(
    'title' => 'RadД«t tabulu'
  ),
  'table_prop' => array(
    'title' => 'Tabulas parametri',
    'ok' => 'GATAVS',
    'cancel' => 'Atcelt',
    'rows' => 'Rindas',
    'columns' => 'Slejas',
    'css_class' => 'Stils', // <=== new 1.0.6
    'width' => 'Platums',
    'height' => 'Augstums',
    'border' => 'RДЃmД«tis',
    'pixels' => 'piks.',
    'cellpadding' => 'AtkДЃpe no rДЃmД«ЕЎa',
    'cellspacing' => 'AttДЃlums starp ЕЎЕ«nДЃm',
    'bg_color' => 'Fona krДЃsa',
    'background' => 'Fonu attД“loЕЎana', // <=== new 1.0.6
    'error' => 'KДјЕ«da',
    'error_rows_nan' => 'Rindas nav skaitlis',
    'error_columns_nan' => 'Slejas nav skaitlis',
    'error_width_nan' => 'Platums nav skaitlis',
    'error_height_nan' => 'Augstums nav skaitlis',
    'error_border_nan' => 'RДЃmД«tis nav skaitlis',
    'error_cellpadding_nan' => 'AtkДЃpe no rДЃmД«ЕЎa nav skaitlis',
    'error_cellspacing_nan' => 'AttДЃlums starp ЕЎЕ«nДЃm nav skaitlis',
  ),
  'table_cell_prop' => array(
    'title' => 'Е Е«nas parametri',
    'horizontal_align' => 'HorizontДЃla izlД«dzinДЃЕЎana',
    'vertical_align' => 'VertikДЃla izlД«dzinДЃЕЎana',
    'width' => 'Platums',
    'height' => 'Augstums',
    'css_class' => 'Stils',
    'no_wrap' => 'Bez pДЃrnesuma',
    'bg_color' => 'Fona krДЃsa',
    'background' => 'Fonu attД“loЕЎana', // <=== new 1.0.6
    'ok' => 'GATAVS',
    'cancel' => 'Atcelt',
    'justifyleft' => 'Pa kreisi',
    'justifycenter' => 'CentrДЃ',
    'justifyright' => 'Pa labi',
    'top' => 'No augЕЎas',
    'bottom' => 'No lejas',
    'baseline' => 'BДЃziska teksta lД«nija',
    'error' => 'KДјЕ«da',
    'error_width_nan' => 'Platums nav skaitlis',
    'error_height_nan' => 'Augstums nav skaitlis',
    
  ),
  'table_row_insert' => array(
    'title' => 'Ielikt rindu'
  ),
  'table_column_insert' => array(
    'title' => 'Ielikt sleju'
  ),
  'table_row_delete' => array(
    'title' => 'AizdabЕ«t rindu'
  ),
  'table_column_delete' => array(
    'title' => 'AizdabЕ«t sleju'
  ),
  'table_cell_merge_right' => array(
    'title' => 'Apvienot pa labi'
  ),
  'table_cell_merge_down' => array(
    'title' => 'Apvienot pa kreisi'
  ),
  'table_cell_split_horizontal' => array(
    'title' => 'SadalД«t pa horizontДЃli'
  ),
  'table_cell_split_vertical' => array(
    'title' => 'SadalД«t pa vertikДЃli'
  ),
  'style' => array(
    'title' => 'Stils'
  ),
  'fontname' => array(
    'title' => 'Е rifts'
  ),
  'fontsize' => array(
    'title' => 'IzmД“rs'
  ),
  'formatBlock' => array(
    'title' => 'Rindkopa'
  ),
  'bold' => array(
    'title' => 'Taukains'
  ),
  'italic' => array(
    'title' => 'KursД«vs'
  ),
  'underline' => array(
    'title' => 'UzsvД“rts'
  ),
  'insertorderedlist' => array(
    'title' => 'NokДЃrtots saraksts'
  ),
  'insertunorderedlist' => array(
    'title' => 'NenokДЃrtots saraksts'
  ),
  'indent' => array(
    'title' => 'PalielinДЃt atkДЃpi'
  ),
  'outdent' => array(
    'title' => 'SamazinДЃt atkДЃpi'
  ),
  'justifyleft' => array(
    'title' => 'IzlД«dzinДЃЕЎana pa kreisi'
  ),
  'justifycenter' => array(
    'title' => 'IzlД«dzinДЃЕЎana pa centru'
  ),
  'justifyright' => array(
    'title' => 'IzlД«dzinДЃЕЎana pa labi'
  ),
  'fore_color' => array(
    'title' => 'Teksta krДЃsa'
  ),
  'bg_color' => array(
    'title' => 'Fona krДЃsa'
  ),
  'design' => array(
    'title' => 'PДЃrslД“gties maketД“ЕЎanas reЕѕД«mДЃ (WYSIWYG)'
  ),
  'html' => array(
    'title' => 'PДЃrslД“gties koda redakcijas reЕѕД«mДЃ (HTML)'
  ),
  'colorpicker' => array(
    'title' => 'KrДЃsas izvД“le',
    'ok' => 'GATAVS',
    'cancel' => 'Atcelt',
  ),
  'cleanup' => array(
    'title' => 'HTML tД«rД«ЕЎana',
    'confirm' => 'Е Д« operДЃcija aizvДЃks visus stilus, ЕЎriftus un nevajadzД«gi tegi no redaktora tekoЕЎДЃ satura. DaДјa vai viss jЕ«su formatД“ЕЎana var bЕ«t nozaudД“ts.',
    'ok' => 'GATAVS',
    'cancel' => 'Atcelt',
  ),
  'toggle_borders' => array(
    'title' => 'IekДјaut rДЃmД«ЕЎus',
  ),
  'hyperlink' => array(
    'title' => 'Links',
    'url' => 'Adrese',
    'name' => 'VДЃrds',
    'target' => 'AtvД“rt',
    'title_attr' => 'Nosaukums',
	'a_type' => 'Tips', // <=== new 1.0.6
	'type_link' => 'Atsauce', // <=== new 1.0.6
	'type_anchor' => 'Enkurs', // <=== new 1.0.6
	'type_link2anchor' => 'links uz enkuru', // <=== new 1.0.6
	'anchors' => 'Enkuri', // <=== new 1.0.6
    'ok' => 'GATAVS',
    'cancel' => 'Atcelt',
  ),
  'hyperlink_targets' => array( // <=== new 1.0.5
  	'_self' => 'tas pats frejms (_self)',
	'_blank' => 'jaunДЃ logДЃ (_blank)',
	'_top' => 'uz visu logu (_top)',
	'_parent' => 'vecДЃku frejms (_parent)'
  ),
  'table_row_prop' => array(
    'title' => 'Rindas parametri',
    'horizontal_align' => 'HorizontДЃla izlД«dzinДЃЕЎana',
    'vertical_align' => 'VertikДЃla izlД«dzinДЃЕЎana',
    'css_class' => 'Stils',
    'no_wrap' => 'Bez pДЃrnesuma',
    'bg_color' => 'Fona krДЃsa',
    'ok' => '??????',
    'cancel' => 'Atcelt',
    'justifyleft' => 'Pa kreisi',
    'justifycenter' => 'CentrДЃ',
    'justifyright' => 'Pa labi',
    'top' => 'No augЕЎas',
    'middle' => 'CentrДЃ',
    'bottom' => 'No lejas',
    'baseline' => 'BДЃziska teksta lД«nija',
  ),
  'symbols' => array(
    'title' => 'SpeciДЃli simboli',
    'ok' => 'GATAVS',
    'cancel' => 'Atcelt',
  ),
  'templates' => array(
    'title' => 'Е abloni',
  ),
  'page_prop' => array(
    'title' => 'Lapaspuses parametri',
    'title_tag' => 'Virsraksts',
    'charset' => 'Simbolu salikums',
    'background' => 'Fonu attД“loЕЎana',
    'bgcolor' => 'Fona krДЃsa',
    'text' => 'Teksta krДЃsa',
    'link' => 'AtsauДЌu krДЃsa',
    'vlink' => 'ApmeklД“to atsauДЌu krДЃsa',
    'alink' => 'AktД«vu atsauДЌu krДЃsa',
    'leftmargin' => 'AtkДЃpe pa kreisi',
    'topmargin' => 'AtkДЃpe no augЕЎas',
    'css_class' => 'Stils',
    'ok' => 'GATAVS',
    'cancel' => 'Atcelt',
  ),
  'preview' => array(
    'title' => 'IepriekЕЎД“ja caurskatД«ЕЎana',
  ),
  'image_popup' => array(
    'title' => 'Popup attД“loЕЎanas',
  ),
  'zoom' => array(
    'title' => 'PalielinДЃЕЎana',
  ),
  'subscript' => array( // <=== new 1.0.7
    'title' => 'ApakЕЎД“js indekss',
  ),
  'superscript' => array( // <=== new 1.0.7
    'title' => 'AugЕЎД“js indekss',
  ),
);
?>