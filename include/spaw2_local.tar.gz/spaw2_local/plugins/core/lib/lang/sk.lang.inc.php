<?php 
// ================================================
// SPAW v.2.0
// ================================================
// Slovak language file
// ================================================
// Developed: Alan Mendelevich, alan@solmetra.lt
// Copyright: Solmetra (c)2003 All rights reserved.
// Slovak translation: Martin Е vec
//                     shuter@vadium.sk
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.2.0
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'VystrihnГєЕҐ'
  ),
  'copy' => array(
    'title' => 'KopГ­rovaЕҐ'
  ),
  'paste' => array(
    'title' => 'VloЕѕiЕҐ'
  ),
  'undo' => array(
    'title' => 'VrГЎtiЕҐ Гєpravy'
  ),
  'redo' => array(
    'title' => 'Znovu vykonaЕҐ Гєpravy'
  ),
  'image' => array(
    'title' => 'RГЅchle vloЕѕenie obrГЎzka'
  ),
  'image_prop' => array(
    'title' => 'ObrГЎzok',
    'ok' => '   OK   ',
    'cancel' => 'ZruЕЎiЕҐ',
    'source' => 'Zdroj',
    'alt' => 'AlternatГ­vny text',
    'align' => 'Zarovnanie',
    'left' => 'vДѕavo',
    'right' => 'vpravo',
    'top' => 'nahor',
    'middle' => 'nastred',
    'bottom' => 'naspodok',
    'absmiddle' => 'absolГєtny stred',
    'texttop' => 'text-nahor',
    'baseline' => 'zГЎkladnГЅ riadok',
    'width' => 'Е Г­rka',
    'height' => 'VГЅЕЎka',
    'border' => 'Okraj',
    'hspace' => 'Horiz. medzera',
    'vspace' => 'Vert. medzera',
    'dimensions' => 'Rozmery', // <= new in 2.0.1
    'reset_dimensions' => 'ObnoviЕҐ rozmery', // <= new in 2.0.1
    'title_attr' => 'Popis', // <= new in 2.0.1
    'constrain_proportions' => 'VynГєtiЕҐ proporcie', // <= new in 2.0.1
    'css_class' => 'CSS trieda', // <= new in 2.0.6
    'error' => 'Chyba',
    'error_width_nan' => 'Е Г­rka nie je ДЌГ­slo',
    'error_height_nan' => 'VГЅЕЎka nie je ДЌГ­slo',
    'error_border_nan' => 'Okraj nie je ДЌГ­slo',
    'error_hspace_nan' => 'HorizontГЎlna medzera nie je ДЌГ­slo',
    'error_vspace_nan' => 'VertikГЎlna medzera nie je ДЌГ­slo',
  ),
  'flash_prop' => array(                // <= new in 2.0
    'title' => 'Flash',
    'ok' => '   OK   ',
    'cancel' => 'ZruЕЎiЕҐ',
    'source' => 'Zdroj',
    'width' => 'Е Г­rka',
    'height' => 'VГЅЕЎka',
    'error' => 'Chyba',
    'error_width_nan' => 'Е Г­rka nie je ДЌГ­slo',
    'error_height_nan' => 'VГЅЕЎka nie je ДЌГ­slo',
  ),
  'inserthorizontalrule' => array( // <== v.2.0 changed from hr
    'title' => 'HorizontГЎlna ДЌiara'
  ),
  'table_create' => array(
    'title' => 'VytvoriЕҐ tabuДѕku'
  ),
  'table_prop' => array(
    'title' => 'Vlastnosti tabuДѕky',
    'ok' => '   OK   ',
    'cancel' => 'ZruЕЎiЕҐ',
    'rows' => 'Riadky',
    'columns' => 'StДєpce',
    'css_class' => 'CSS trieda',
    'width' => 'Е Г­rka',
    'height' => 'VГЅЕЎka',
    'border' => 'Okraj',
    'pixels' => 'pixlov',
    'cellpadding' => 'Odsadenie v bunke',
    'cellspacing' => 'VzdialenosЕҐ buniek',
    'bg_color' => 'Farba pozadia',
    'background' => 'ObrГЎzok pozadia',
    'error' => 'Chyba',
    'error_rows_nan' => 'Riadky nie sГє ДЌГ­slo',
    'error_columns_nan' => 'StДєpce nie sГє ДЌГ­slo',
    'error_width_nan' => 'Е Г­rka nie je ДЌГ­slo',
    'error_height_nan' => 'VГЅЕЎka nie je ДЌГ­slo',
    'error_border_nan' => 'Okraj nie je ДЌГ­slo',
    'error_cellpadding_nan' => 'Odsadenie v bunke nie je ДЌГ­slo',
    'error_cellspacing_nan' => 'VzdialenosЕҐ buniek nie je ДЌГ­slo',
  ),
  'table_cell_prop' => array(
    'title' => 'Vlastnosti bunky',
    'horizontal_align' => 'HorizontГЎlne zarovnanie',
    'vertical_align' => 'VertikГЎlne zarovnanie',
    'width' => 'Е Г­rka',
    'height' => 'VГЅЕЎka',
    'css_class' => 'CSS trieda',
    'no_wrap' => 'NezalamovaЕҐ',
    'bg_color' => 'Farba pozadia',
    'background' => 'ObrГЎzok pozadia',
    'ok' => '   OK   ',
    'cancel' => 'ZruЕЎiЕҐ',
    'left' => 'VДѕavo',
    'center' => 'CentrovaЕҐ',
    'right' => 'Vpravo',
    'top' => 'Nahor',
    'middle' => 'Nastred',
    'bottom' => 'Naspodok',
    'baseline' => 'ZГЎkladnГЅ riadok',
    'error' => 'Chyba',
    'error_width_nan' => 'Е Г­rka nie je ДЌГ­slo',
    'error_height_nan' => 'VГЅЕЎka nie je ДЌГ­slo',
  ),
  'table_row_insert' => array(
    'title' => 'VloЕѕiЕҐ riadok'
  ),
  'table_column_insert' => array(
    'title' => 'VloЕѕiЕҐ stДєpec'
  ),
  'table_row_delete' => array(
    'title' => 'VymazaЕҐ riadok'
  ),
  'table_column_delete' => array(
    'title' => 'VymazaЕҐ stДєpec'
  ),
  'table_cell_merge_right' => array(
    'title' => 'ZlГєДЌiЕҐ vpravo'
  ),
  'table_cell_merge_down' => array(
    'title' => 'ZlГєДЌiЕҐ nadol'
  ),
  'table_cell_split_horizontal' => array(
    'title' => 'RozdeliЕҐ bunku horizontГЎlne'
  ),
  'table_cell_split_vertical' => array(
    'title' => 'RozdeliЕҐ bunku vertikГЎlne'
  ),
  'style' => array(
    'title' => 'Е tГЅl'
  ),
  'fontname' => array( // <== v.2.0 changed from font
    'title' => 'PГ­smo'
  ),
  'fontsize' => array(
    'title' => 'VeДѕkosЕҐ'
  ),
  'formatBlock' => array( // <= v.2.0: changed from paragraph
    'title' => 'Odstavec'
  ),
  'bold' => array(
    'title' => 'HrubГ©'
  ),
  'italic' => array(
    'title' => 'Е ikmГ©'
  ),
  'underline' => array(
    'title' => 'PodДЌiarknutГ©'
  ),
  'strikethrough' => array(
    'title' => 'PreЕЎkrtnutГ©'
  ),
  'insertorderedlist' => array( // <== v.2.0 changed from ordered_list
    'title' => 'ДЊГ­slovanГЅ zoznam'
  ),
  'insertunorderedlist' => array( // <== v.2.0 changed from bulleted list
    'title' => 'NeДЌГ­slovanГЅ zoznam'
  ),
  'indent' => array(
    'title' => 'Odsadenie'
  ),
  'outdent' => array( // <== v.2.0 changed from unindent
    'title' => 'ZruЕЎiЕҐ odsadenie'
  ),
  'justifyleft' => array( // <== v.2.0 changed from left
    'title' => 'VДѕavo'
  ),
  'justifycenter' => array( // <== v.2.0 changed from center
    'title' => 'CentrovaЕҐ'
  ),
  'justifyright' => array( // <== v.2.0 changed from right
    'title' => 'Vpravo'
  ),
  'justifyfull' => array( // <== v.2.0 changed from justify
    'title' => 'Do bloku'
  ),
  'fore_color' => array(
    'title' => 'Farba popredia'
  ),
  'bg_color' => array(
    'title' => 'Farba pozadia'
  ),
  'design' => array( // <== v.2.0 changed from design_tab
    'title' => 'PrepnГєЕҐ do WYSIWYG (dizajn) mГіdu'
  ),
  'html' => array( // <== v.2.0 changed from html_tab
    'title' => 'PrepnГєЕҐ do HTML (kГіd) mГіdu'
  ),
  'colorpicker' => array(
    'title' => 'Paleta farieb',
    'ok' => '   OK   ',
    'cancel' => 'ZruЕЎiЕҐ',
  ),
  'cleanup' => array(
    'title' => 'HTML vyДЌistiЕҐ (odstrГЎniЕҐ ЕЎtГЅly)',
    'confirm' => 'VykonanГ­m akcie odstrГЎnite vЕЎetky ЕЎtГЅly, fonty a zbytoДЌnГ© tagy z aktuГЎlneho obsahu. NiektorГ© alebo vЕЎetky formГЎtovania budГє odstrГЎnenГ©.',
    'ok' => '   OK   ',
    'cancel' => 'ZruЕЎiЕҐ',
  ),
  'toggle_borders' => array(
    'title' => 'ZapnГєЕҐ zobrazenie okrajov tabДѕky',
  ),
  'hyperlink' => array(
    'title' => 'HypertextovГЅ odkaz',
    'url' => 'URL',
    'name' => 'Meno',
    'target' => 'CieДѕ',
    'title_attr' => 'Popis',
  	'a_type' => 'Typ',
  	'type_link' => 'Odkaz',
  	'type_anchor' => 'Kotva',
  	'type_link2anchor' => 'Odkaz do Kotvy',
  	'anchors' => 'Kotvy',
  	'quick_links' => "RГЅchle odkazy", // <=== new in 2.0.6
    'ok' => '   OK   ',
    'cancel' => 'ZruЕЎiЕҐ',
  ),
  'hyperlink_targets' => array(
  	'_self' => 'to istГ© okno (_self)',
  	'_blank' => 'novГ© okno (_blank)',
  	'_top' => 'hornГЅ rГЎm (_top)',
  	'_parent' => 'rodiДЌovskГЅ rГЎm (_parent)'
  ),
  'unlink' => array( // <=== new v.2.0
    'title' => 'OdstrГЎniЕҐ hypertextovГЅ odkaz'
  ),
  'table_row_prop' => array(
    'title' => 'Vlastnosti riadku tabuДѕky',
    'horizontal_align' => 'HorizontГЎlne zarovnanie',
    'vertical_align' => 'VertikГЎlne zarovnanie',
    'css_class' => 'CSS trieda',
    'no_wrap' => 'NezalamovaЕҐ',
    'bg_color' => 'Farba pozadia',
    'ok' => '   OK   ',
    'cancel' => 'ZruЕЎiЕҐ',
    'left' => 'VДѕavo',
    'center' => 'CentrovaЕҐ',
    'right' => 'Vpravo',
    'top' => 'Nahor',
    'middle' => 'Nastred',
    'bottom' => 'Naspodok',
    'baseline' => 'ZГЎkladnГЅ riadok',
  ),
  'symbols' => array(
    'title' => 'Е peciГЎlne znaky',
    'ok' => '   OK   ',
    'cancel' => 'ZruЕЎiЕҐ',
  ),
  'templates' => array(
    'title' => 'ЕЎablГіny',
  ),
  'page_prop' => array(
    'title' => 'Vlastnosti strГЎnky',
    'title_tag' => 'NГЎzov',
    'charset' => 'KГіdovanie',
    'background' => 'ObrГЎzok pozadia',
    'bgcolor' => 'Farba pozadia',
    'text' => 'Farba textu',
    'link' => 'Farba odkazu',
    'vlink' => 'Farba navЕЎtГ­venГ©ho odkazu',
    'alink' => 'Farba aktГ­vneho odkazu',
    'leftmargin' => 'ДЅavГЅ okraj',
    'topmargin' => 'HornГЅ okraj',
    'css_class' => 'CSS trieda',
    'ok' => '   OK   ',
    'cancel' => 'ZruЕЎiЕҐ',
  ),
  'preview' => array(
    'title' => 'NГЎhДѕad',
  ),
  'image_popup' => array(
    'title' => 'RozklikГЎvacГ­ obrГЎzok',
  ),
  'zoom' => array(
    'title' => 'ZvГ¤ДЌЕЎenie',
  ),
  'subscript' => array(
    'title' => 'DolnГЅ index',
  ),
  'superscript' => array(
    'title' => 'HornГЅ index',
  ),
);
?>