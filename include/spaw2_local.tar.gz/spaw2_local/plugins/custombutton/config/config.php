<?php
SpawConfig::setStaticConfigItem(
  'PG_CUSTOMBUTTON_TEMPLATE',
  '<b>something in front</b>%%CURRENT_CONTENT%%<i>something in the end</i>',
  SPAW_CFG_TRANSFER_JS
);
?>