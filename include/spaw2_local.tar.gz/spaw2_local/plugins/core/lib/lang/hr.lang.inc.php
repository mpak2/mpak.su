<?php 
// ================================================
// SPAW PHP WYSIWYG editor control
// ================================================
// Slovenian language file
// ================================================
// Developed: Alan Mendelevich, alan@solmetra.lt
// Copyright: Solmetra (c)2003 All rights reserved.
// Croatian translation:  
//                         dragan@pfri.hr
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.1.0, 2003-03-20
// ================================================



// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'IzreЕѕi'
  ),
  'copy' => array(
    'title' => 'Kopiraj'
  ),
  'paste' => array(
    'title' => 'Zalijepi'
  ),
  'undo' => array(
    'title' => 'PoniЕЎti'
  ),
  'redo' => array(
    'title' => 'Obnovi'
  ),
  'hyperlink' => array(
    'title' => 'Poveznica'
  ),
  'image_insert' => array(
    'title' => 'Unos slike',
    'select' => 'Izbor',
    'cancel' => 'Prekid',
    'library' => 'KnjiЕѕnica',
    'preview' => 'Pregled',
    'images' => 'Slike',
    'upload' => 'Unos slike',
    'upload_button' => 'Unos',
    'error' => 'GrjeЕЎka',
    'error_no_image' => 'Izaberite sliku',
    'error_uploading' => 'GrjeЕЎka pri unosu slike. Ponovite molim',
    'error_wrong_type' => 'Datoteka ne sadrЕѕi sliku',
    'error_no_dir' => 'KnjiЕѕnica ne postoji / nije dostupna',
  ),
  'image_prop' => array(
    'title' => 'Naziv slike',
    'ok' => '   OK   ',
    'cancel' => 'Prekid',
    'source' => 'Izvor',
    'alt' => 'Alternativni naziv',
    'align' => 'Poravnaj',
    'justifyleft' => 'lijevo',
    'justifyright' => 'desno',
    'top' => 'gore',
    'middle' => 'u sredinu',
    'bottom' => 'dolje',
    'absmiddle' => 'apsolutna sredina',
    'texttop' => 'na vrh teksta',
    'baseline' => 'na osnovni red',
    'width' => 'Е irina',
    'height' => 'Visina',
    'border' => 'Obrub',
    'hspace' => 'Vodoravni. razmak',
    'vspace' => 'Okomiti razmak',
    'error' => 'GrjeЕЎka',
    'error_width_nan' => 'Е irina mora biti  brojДЌana vrijednost',
    'error_height_nan' => 'Visina mora biti  brojДЌana vrijednost',
    'error_border_nan' => 'Obrub mora biti  brojДЌana vrijednost',
    'error_hspace_nan' => 'Vodoravni razmak  brojДЌana vrijednost',
    'error_vspace_nan' => 'Okomiti razmik mora brojДЌana vrijednost',
  ),
  'inserthorizontalrule' => array(
    'title' => 'Vodoravna crta'
  ),
  'table_create' => array(
    'title' => 'Tablica'
  ),
  'table_prop' => array(
    'title' => 'Naziv tablice',
    'ok' => '   OK   ',
    'cancel' => 'Prekid',
    'rows' => 'red',
    'columns' => 'stubac',
    'width' => 'Е irina',
    'height' => 'Visina',
    'border' => 'Debljina obruba',
    'pixels' => 'pixela',
    'cellpadding' => 'Debljina obloge Д‡elije',
    'cellspacing' => 'Razmak meД‘u Д‡elijama',
    'bg_color' => 'Boja pozadine',
    'error' => 'GrjeЕЎka',
    'error_rows_nan' => 'Broj redova  mora biti  brojДЌana vrijednost',
    'error_columns_nan' => 'Broj stubaca  mora biti  brojДЌana vrijednost',
    'error_width_nan' => 'Е irina mora biti  brojДЌana vrijednost',
    'error_height_nan' => 'Visina mora biti  brojДЌana vrijednost',
    'error_border_nan' => 'Debljina obrube mora biti  brojДЌana vrijednost',
    'error_cellpadding_nan' => 'Debljina obloge Д‡elije mora biti  brojДЌana vrijednost',
    'error_cellspacing_nan' => 'Razmak meД‘u Д‡elijama mora biti  brojДЌana vrijednost',
  ),
  'table_cell_prop' => array(
    'title' => 'Svojstva Д‡elije',
    'horizontal_align' => 'vodoravno poravnanje',
    'vertical_align' => 'horizontalno  poravnanje',
    'width' => 'Е irina',
    'height' => 'Visina',
    'css_class' => 'CSS razred',
    'no_wrap' => 'Brez prijeloma (wrap)',
    'bg_color' => 'Boja pozadine',
    'ok' => '   OK   ',
    'cancel' => 'Prekin',
    'justifyleft' => 'Lijevo',
    'justifycenter' => 'Centar',
    'justifyright' => 'Desno',
    'top' => 'Gore',
    'middle' => 'Sredina',
    'bottom' => 'Dolje',
    'baseline' => 'Osnovna linija',
    'error' => 'GrjeЕЎka',
    'error_width_nan' => 'Е irina  mora biti  brojДЌana vrijednost',
    'error_height_nan' => 'Visina mora biti  brojДЌana vrijednost',
  ),
  'table_row_insert' => array(
    'title' => 'Unos reda'
  ),
  'table_column_insert' => array(
    'title' => 'Unos stupca'
  ),
  'table_row_delete' => array(
    'title' => 'Brisanje reda'
  ),
  'table_column_delete' => array(
    'title' => 'BriЕЎanje stupca'
  ),
  'table_cell_merge_right' => array(
    'title' => 'Unos na desno'
  ),
  'table_cell_merge_down' => array(
    'title' => 'Unos ispod'
  ),
  'table_cell_split_horizontal' => array(
    'title' => 'Vodoravno podijeli Д‡eliju'
  ),
  'table_cell_split_vertical' => array(
    'title' => 'Okomito podijeli Д‡eliju'
  ),
  'style' => array(
    'title' => 'Stil'
  ),
  'fontname' => array(
    'title' => 'Font'
  ),
  'fontsize' => array(
    'title' => 'VeliДЌina'
  ),
  'formatBlock' => array(
    'title' => 'Odlomak'
  ),
  'bold' => array(
    'title' => 'Podebljano'
  ),
  'italic' => array(
    'title' => 'Kurziv'
  ),
  'underline' => array(
    'title' => 'Podcrtano'
  ),
  'insertorderedlist' => array(
    'title' => 'Numeriranje'
  ),
  'insertunorderedlist' => array(
    'title' => 'GrafiДЌke oznake'
  ),
  'indent' => array(
    'title' => 'PoveД‡aj uvlaku'
  ),
  'outdent' => array(
    'title' => 'Smanji uvlaku'
  ),
  'justifyleft' => array(
    'title' => 'Lijevo'
  ),
  'justifycenter' => array(
    'title' => 'Center'
  ),
  'justifyright' => array(
    'title' => 'Desno'
  ),
  'fore_color' => array(
    'title' => 'Boja prednjice'
  ),
  'bg_color' => array(
    'title' => 'Boja pozadine'
  ),
  'design' => array(
    'title' => 'Pregled izgleda '
  ),
  'html' => array(
    'title' => 'Pregled  HTML koda'
  ),
  'colorpicker' => array(
    'title' => 'Boje',
    'ok' => '   OK   ',
    'cancel' => 'Prekid',
  ),
  'cleanup' => array(
    'title' => 'ДЊiЕЎДЌenje HTML (odstranjivanje stilova)',
    'confirm' => 'Brisanje stilova iz HTML koda. Stilovi su djelomice ili potpuno izbrisani.',
    'ok' => '   OK   ',
    'cancel' => 'Prekid',
  ),
  'toggle_borders' => array(
    'title' => 'Preklop obruba',
  ),
  'hyperlink' => array(
    'title' => 'Poveznica',
    'url' => 'URL ( poveznica )',
    'name' => 'Naziv',
    'target' => 'OdrediЕЎni okvir',
    'title_attr' => 'Tekst za prikaz',
    'ok' => '   OK   ',
    'cancel' => 'Prekid',
  ),
  'table_row_prop' => array(
    'title' => 'Svojstva redova',
    'horizontal_align' => 'Vodoravno poravnanje',
    'vertical_align' => 'Okomito poravnanje',
    'css_class' => 'CSS razred',
    'no_wrap' => 'Brez prijeloma (wrap)',
    'bg_color' => 'Boja pozadine',
    'ok' => '   OK   ',
    'cancel' => 'Prekid',
    'justifyleft' => 'Lijevo',
    'justifycenter' => 'Centar',
    'justifyright' => 'Desno',
    'top' => 'Gore',
    'middle' => 'Sredina',
    'bottom' => 'Dolje',
    'baseline' => 'Osnovna linija',
  ),
  'symbols' => array(
    'title' => 'Posebni znaci',
    'ok' => '   OK   ',
    'cancel' => 'Prekid',
  ),
  'templates' => array(
    'title' => 'Podloge',
  ),
  'page_prop' => array(
    'title' => 'Svojstva  stranice',
    'title_tag' => 'Naslov',
    'charset' => 'Prikaz slova ( charset)',
    'background' => 'Slika u pozadini',
    'bgcolor' => 'Boja ppozadine',
    'text' => 'Boja slova teksta',
    'link' => 'Boja poveznica',
    'vlink' => 'Boja posjeД‡ene poveznice',
    'alink' => 'Boja aktivne poveznice',
    'leftmargin' => 'Margina lijevo',
    'topmargin' => 'Margina gore',
    'css_class' => 'CSS razred',
    'ok' => '   OK   ',
    'cancel' => 'Prekid',
  ),
  'preview' => array(
    'title' => 'Pregled',
  ),
  'image_popup' => array(
    'title' => 'Popup sa slikom',
  ),
  'zoom' => array(
    'title' => 'PoveД‡aj ( Zoom )',
  ),
);
?>