<?php
// ================================================
// SPAW v.2.0
// ================================================
// Bulgarian language file
// ================================================
// Developed: Alan Mendelevich, alan@solmetra.lt
// Copyright: Solmetra (c)2003 All rights reserved.
// Translated: Atanas Tchobanov, atanas@webdressy.com
// Updated: Stoyan Dimitrov, stoyanster@gmail.com, 04.12.2007
// ------------------------------------------------
//                                 www.solmetra.com
// ================================================
// v.2.0
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array (
	'cut' => array (
		'title' => 'РћС‚СЂСЏР·РІР°РЅРµ'
	),
	'copy' => array (
		'title' => 'РљРѕРїРёСЂР°РЅРµ'
	),
	'paste' => array (
		'title' => 'Р’РјСЉРєРІР°РЅРµ'
	),
	'undo' => array (
		'title' => 'РћС‚РјСЏРЅР°'
	),
	'redo' => array (
		'title' => 'РџРѕРІС‚Р°СЂСЏРЅРµ'
	),
	'image' => array (
		'title' => 'Р