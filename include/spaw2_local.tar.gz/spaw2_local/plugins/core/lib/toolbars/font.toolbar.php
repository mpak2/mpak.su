<?php
$items = array
(
  new SpawTbDropdown("core", "fontname", "isStandardFunctionEnabled", "standardFunctionStatusCheck", "fontFamilyChange"),
  new SpawTbDropdown("core", "fontsize", "isStandardFunctionEnabled", "standardFunctionStatusCheck", "fontSizeChange"),
  new SpawTbImage("core", "separator"),
);
?>
