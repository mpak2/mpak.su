<?php 
// ================================================
// SPAW v.2.0
// ================================================
//
//
// Arabic language file
// Traslated: Mohammed Ahmed
// Gaza, Palestine
// http://www.maaking.com
// Email/MSN: m@maaking.com
//
// last update: 18-oct-2007
//
// ================================================
// Author: Alan Mendelevich, UAB Solmetra
// ------------------------------------------------
// www.solmetra.com
// ================================================
// v.2.0
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'windows-1256';


// text direction for the language
$spaw_lang_direction = 'rtl';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'ЮХ'
  ),
  'copy' => array(
    'title' => 'дУО'
  ),
  'paste' => array(
    'title' => 'бХЮ'
  ),
  'undo' => array(
    'title' => 'КСЗМЪ'
  ),
  'redo' => array(
    'title' => 'ЕЪЗПЙ ЗбКСЗМЪ'
  ),
  'image' => array(
    'title' => 'ЕПСЗМ ХжСЙ'
  ),
  'image_prop' => array(
    'title' => 'ХжСЙ',
    'ok' => '   гжЗЭЮ   ',
    'cancel' => 'ЕбЫЗБ',
    'source' => 'ЗбгХПС',
    'alt' => 'дХ ИПнб',
    'align' => 'ЗбгНЗРЗе',
    'left' => 'нУЗС',
    'right' => 'нгнд',
    'top' => 'ГЪбм',
    'middle' => 'жУШ',
    'bottom' => 'ГУЭб',
    'absmiddle' => 'дХ Эн ЗбгдКХЭ',
    'texttop' => 'дХ Эн ЗбГЪбм',
    'baseline' => 'ОШ ГУЗУн',
    'width' => 'ЗбЪСЦ',
    'height' => 'ЗбЕСКЭЗЪ',
    'border' => 'ЗбНП',
    'hspace' => 'гУЗЭЙ ГЭЮнЙ',
    'vspace' => 'гУЗЭЙ ЪгжПнЙ',
    'dimensions' => 'ЗбГИЪЗП', // <= new in 2.0.1
    'reset_dimensions' => 'ЕЪЗПЙ ЦИШ ЗбГИЪЗП', // <= new in 2.0.1
    'title_attr' => 'ЗбЪджЗд', // <= new in 2.0.1
    'constrain_proportions' => 'ОнЗСЗК гЮнПЙ', // <= new in 2.0.1
    'error' => 'ОШГ',
    'error_width_nan' => 'ЗбЪСЦ бнУ СЮг',
    'error_height_nan' => 'ЗбЕСКЭЗЪ бнУ СЮг',
    'error_border_nan' => 'ЗбНП бнУ СЮг',
    'error_hspace_nan' => 'ЗбЮнгЙ ЗбгПОбЙ бнУ СЮг',
    'error_vspace_nan' => 'ЗбЮнгЙ ЗбгПОбЙ бнУ СЮг',
  ),
  'flash_prop' => array(                // <= new in 2.0
    'title' => 'ЭбЗФ',
    'ok' => '   гжЗЭЮ   ',
    'cancel' => 'ЕбЭЗБ',
    'source' => 'ЗбгХПС',
    'width' => 'ЗбЪСЦ',
    'height' => 'ЗбЕСКЭЗЪ',
    'error' => 'ОШГ',
    'error_width_nan' => 'ЗбЮнгЙ ЗбгПОбЙ бнУ СЮг',
    'error_height_nan' => 'ЗбЮнгЙ ЗбгПОбЙ бнУ СЮг',
  ),
  'inserthorizontalrule' => array( // <== v.2.0 changed from hr
    'title' => 'ЕПСЗМ ОШ ГЭЮн'
  ),
  'table_create' => array(
    'title' => 'ЕдФЗБ МПжб'
  ),
  'table_prop' => array(
    'title' => 'ОХЗЖХ ЗбМПжб',
    'ok' => '   гжЗЭЮ   ',
    'cancel' => 'ЕбЫЗБ',
    'rows' => 'ЗбХЭжЭ',
    'columns' => 'ЗбГЪгПЙ',
    'css_class' => 'CSS КдУнЮ',
    'width' => 'ЗбЪСЦ',
    'height' => 'ЗбЕСКЭЗЪ',
    'border' => 'ЗбНП',
    'pixels' => 'ИЯУб',
    'cellpadding' => 'дШЗЮ ЗбОбнЙ',
    'cellspacing' => 'ЗбгУЗЭЙ Инд ЗбОбЗнЗ',
    'bg_color' => 'бжд ЗбОбЭнЙ',
    'background' => 'ХжСЙ ббОбЭнЙ',
    'error' => 'ОШГ',
    'error_rows_nan' => 'ЗбЮнгЙ ЗбгПОбЙ бнУ СЮг',
    'error_columns_nan' => 'ЗбЮнгЙ ЗбгПОбЙ бнУ СЮг',
    'error_width_nan' => 'ЗбЮнгЙ ЗбгПОбЙ бнУ СЮг',
    'error_height_nan' => 'ЗбЮнгЙ ЗбгПОбЙ бнУ СЮг',
    'error_border_nan' => 'ЗбЮнгЙ ЗбгПОбЙ бнУ СЮг',
    'error_cellpadding_nan' => 'ЗбЮнгЙ ЗбгПОбЙ бнУ СЮг',
    'error_cellspacing_nan' => 'ЗбЮнгЙ ЗбгПОбЙ бнУ СЮг',
  ),
  'table_cell_prop' => array(
    'title' => 'ОХЗЖХ ЗбОбнЙ',
    'horizontal_align' => 'гНЗРЗЙ ГЭЮнЙ',
    'vertical_align' => 'гНЗРЗЙ ЪгжПнЙ',
    'width' => 'ЗбЪСЦ',
    'height' => 'ЗбЗСКЭЗЪ',
    'css_class' => 'CSS дгШ',
    'no_wrap' => 'ИбЗ бЭ',
    'bg_color' => 'бжд ЗбОбЭнЙ',
    'background' => 'ХжСЙ ЗбОбЭнЙ',
    'ok' => '   гжЗЭЮ   ',
    'cancel' => 'ЕбЫЗБ',
    'left' => 'нУЗС',
    'center' => 'жУШ',
    'right' => 'нгнд',
    'top' => 'ГЪбм',
    'middle' => 'жУШ',
    'bottom' => 'ГУЭб',
    'baseline' => 'ОШ ГУЗУн',
    'error' => 'ОШГ',
    'error_width_nan' => 'ЗбЮнгЙ ЗбгПОбЙ бнУ СЮг',
    'error_height_nan' => 'ЗбЮнгЙ ЗбгПОбЙ бнУ СЮг',
  ),
  'table_row_insert' => array(
    'title' => 'ЕПСЗМ ХЭ'
  ),
  'table_column_insert' => array(
    'title' => 'ЕПЗСМ ЪгжП'
  ),
  'table_row_delete' => array(
    'title' => 'НРЭ ХЭ'
  ),
  'table_column_delete' => array(
    'title' => 'НРЭ ЪгжП'
  ),
  'table_cell_merge_right' => array(
    'title' => 'ПгМ Ебм Збнгнд'
  ),
  'table_cell_merge_down' => array(
    'title' => 'ПгМ Ебм ЗбГУЭб'
  ),
  'table_cell_split_horizontal' => array(
    'title' => 'ЮУг ЗбОбЗнЗ ИФЯб ГЭЮн'
  ),
  'table_cell_split_vertical' => array(
    'title' => 'КЮУнг ЗбОбЗнЗ ИФЯб ЪгжПн'
  ),
  'style' => array(
    'title' => 'ЗбдгШ'
  ),
  'fontname' => array( // <== v.2.0 changed from font
    'title' => 'ЗбОШ'
  ),
  'fontsize' => array(
    'title' => 'ЗбНМг'
  ),
  'formatBlock' => array( // <= v.2.0: changed from paragraph
    'title' => 'ЗбЭЮСЙ'
  ),
  'bold' => array(
    'title' => 'ЪСнЦ'
  ),
  'italic' => array(
    'title' => 'гЗЖб'
  ),
  'underline' => array(
    'title' => 'КНКе ОШ'
  ),
  'strikethrough' => array(
    'title' => 'жУШе ОШ'
  ),
  'insertorderedlist' => array( // <== v.2.0 changed from ordered_list
    'title' => 'дЪПЗП СЮгн'
  ),
  'insertunorderedlist' => array( // <== v.2.0 changed from bulleted list
    'title' => 'КЪПЗП дЮШн'
  ),
  'indent' => array(
    'title' => 'ТнЗПЙ ЗбгУЗЭЙ ЗбИЗПЖЙ'
  ),
  'outdent' => array( // <== v.2.0 changed from unindent
    'title' => 'ЗдЮЗХ ЗбгУЗЭЙ ЗбИЗПЖЙ'
  ),
  'justifyleft' => array( // <== v.2.0 changed from left
    'title' => 'нУЗС'
  ),
  'justifycenter' => array( // <== v.2.0 changed from center
    'title' => 'КжУнШ'
  ),
  'justifyright' => array( // <== v.2.0 changed from right
    'title' => 'нгнд'
  ),
  'justifyfull' => array( // <== v.2.0 changed from justify
    'title' => 'ЦИШ'
  ),
  'fore_color' => array(
    'title' => 'бжд ЗбОШ'
  ),
  'bg_color' => array(
    'title' => 'бжд ОбЭнЙ ЗбОШ'
  ),
  'design' => array( // <== v.2.0 changed from design_tab
    'title' => 'жЦЪ ЗбКдУнЮ'
  ),
  'html' => array( // <== v.2.0 changed from html_tab
    'title' => 'ЪСЦ ЗбгХПС'
  ),
  'colorpicker' => array(
    'title' => 'ЗдКЮЗБ бжд',
    'ok' => '   гжЗЭЮ   ',
    'cancel' => 'ЕбЫЗБ',
  ),
  'cleanup' => array(
    'title' => 'гУН ЯЗЭЙ ЗбКдУнЮЗК',
    'confirm' => ' КдЭнР еРЗ ЗбГгС УнгУН ЯЗЭЙ ЗбКдУнЮЗК ЗбКн ЮгК ИЪгбеЗ. ',
    'ok' => '   гжЗЭЮ   ',
    'cancel' => 'ЕбЫЗБ',
  ),
  'toggle_borders' => array(
    'title' => 'ТнЗПЙ ЗбНПжП',
  ),
  'hyperlink' => array(
    'title' => 'СЗИШ КФЪИн',
    'url' => 'ЗбЗСИШ URL',
    'name' => 'ЗУг',
    'target' => 'ЗбЕШЗС ЗбеПЭ',
    'title_attr' => 'ЗбЪджЗд',
  	'a_type' => 'ЗбджЪ',
  	'type_link' => 'ЗбСЗИШ',
  	'type_anchor' => 'жХбЙ',
  	'type_link2anchor' => 'СИШ Збм жХбЙ',
  	'anchors' => 'жХбЗК',
    'ok' => '   гжЗЭЮ   ',
    'cancel' => 'ЕбЫЗБ',
  ),
  'hyperlink_targets' => array(
  	'_self' => 'дЭУ ЗбЗШЗС (_self)',
  	'_blank' => 'ХЭНЙ МПнПЙ (_blank)',
  	'_top' => 'ЗШЗС ЗбЪбжн (_top)',
  	'_parent' => 'ЗбГИ (_parent)'
  ),
  'unlink' => array( // <=== new v.2.0
    'title' => 'ЕТЗбЙ ЗбСЗИШ ЗбКФЪИн'
  ),
  'table_row_prop' => array(
    'title' => 'ОХЗЖХ ЗбХЭ',
    'horizontal_align' => 'гНЗРЗЙ ГЭЮнЙ',
    'vertical_align' => 'гНЗРЗЙ ЪгжПнЙ',
    'css_class' => 'CSS дгШ',
    'no_wrap' => 'ИбЗ бЭ',
    'bg_color' => 'бжд ЗбОбЭнЙ',
    'ok' => '   гжЗЭЮ   ',
    'cancel' => 'ЗбЫЗБ',
    'left' => 'нУЗС',
    'center' => 'жУШ',
    'right' => 'нгнд',
    'top' => 'ГЪбм',
    'middle' => 'жУШ',
    'bottom' => 'ГУЭб',
    'baseline' => 'ОШ ГУЗУн',
  ),
  'symbols' => array(
    'title' => 'ГНСЭ ОЗХЙ',
    'ok' => '   гжЗЭЮ   ',
    'cancel' => 'ЕбЫЗБ',
  ),
  'templates' => array(
    'title' => 'ЮжЗбИ',
  ),
  'page_prop' => array(
    'title' => 'ОХЗЖХ ЗбХЭНЙ',
    'title_tag' => 'ЗбЪджЗд',
    'charset' => 'ЗбКСгнТ',
    'background' => 'ХжСЙ ЗбОбЭнЙ',
    'bgcolor' => 'бжд ЗбОбЭнЙ',
    'text' => 'бжд ЗбдХ',
    'link' => 'бжд ЗбСЗИШ',
    'vlink' => 'бжд ЗбСЗИШ Кг ТнЗСКе',
    'alink' => 'бжд ЗбСЗИШ ЗбНн',
    'leftmargin' => 'ЗбНП ЗбГнУС',
    'topmargin' => 'ЗбНП ЗбЪбжн',
    'css_class' => 'CSS КдУнЮ',
    'ok' => '   гжЗЭЮ   ',
    'cancel' => 'ЕбЫЗБ',
  ),
  'preview' => array(
    'title' => 'гЪЗндЙ',
  ),
  'image_popup' => array(
    'title' => 'ХжСЙ Эн дЗЭРЙ',
  ),
  'zoom' => array(
    'title' => 'КЯИнС',
  ),
  'subscript' => array(
    'title' => 'дХ УЭбн',
  ),
  'superscript' => array(
    'title' => 'дХ Ъбжн',
  ),
);
?>
