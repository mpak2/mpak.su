<?php
// ================================================
// SPAW PHP WYSIWYG editor control
// ================================================
// Chinese Big5 language file 
// ================================================
// Developed: Alan Mendelevich, alan@solmetra.lt
// Chinese translation: aman@wealthgrp.com.tw;aman@516888.com;aman77@pchome.com.tw
// Copyright: Solmetra (c)2003 All rights reserved.
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.1.0, 2003-03-20
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'е‰Єдё‹'
  ),
  'copy' => array(
    'title' => 'еѕ©е€¶'
  ),
  'paste' => array(
    'title' => 'иІјдёЉ'
  ),
  'undo' => array(
    'title' => 'еѕ©еЋџ'
  ),
  'redo' => array(
    'title' => 'еЏЌеѕ©еЋџ'
  ),
  'hyperlink' => array(
    'title' => 'и¶…йЂЈзµђ'
  ),
  'image_insert' => array(
    'title' => 'жЏ’е…Ґењ–з‰‡',
    'select' => 'йЃёеЏ–',
    'cancel' => 'еЏ–ж¶€',
    'library' => 'иі‡ж–™е¤ѕ',
    'preview' => 'й ђи¦Ѕ',
    'images' => 'ењ–з‰‡',
    'upload' => 'дёЉе‚іењ–з‰‡',
    'upload_button' => 'дёЉе‚і',
    'error' => 'йЊЇиЄ¤',
    'error_no_image' => 'и«‹йЃёе®љењ–з‰‡',
    'error_uploading' => 'жЄ”жЎ€дёЉе‚із™јз”џйЊЇиЄ¤. и«‹зЁЌеѕЊй‡Ќе‚і',
    'error_wrong_type' => 'жЄ”жЎ€ећ‹ж…‹дёЌз¬¦',
    'error_no_dir' => 'ж‰ѕдёЌе€°иі‡ж–™е¤ѕ',
  ),
  'image_prop' => array(
    'title' => 'ењ–жЄ”е±¬жЂ§',
    'ok' => '   зўєе®љ   ',
    'cancel' => 'еЏ–ж¶€',
    'source' => 'дѕ†жєђ',
    'alt' => 'ж–‡е­—жЏђз¤є',
    'align' => 'е°ЌйЅЉ',
    'justifyleft' => 'е·¦',
    'justifyright' => 'еЏі',
    'top' => 'дёЉ',
    'middle' => 'дё­',
    'bottom' => 'дё‹',
    'absmiddle' => 'зµ•е°Ќдё­е¤®',
    'texttop' => 'ж–‡е­—й ‚з«Ї',
    'baseline' => 'еџєжє–з·љ',
    'width' => 'еЇ¬еє¦',
    'height' => 'й«