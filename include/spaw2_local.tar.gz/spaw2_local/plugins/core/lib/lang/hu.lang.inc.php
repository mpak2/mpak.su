<?php 
// ================================================
// SPAW v.2.0
// ================================================
// English language file
// ================================================
// Author: Alan Mendelevich, UAB Solmetra
// Translated: Szentgyцrgyi Jбnos, info@dynamicart.hu
// ------------------------------------------------
//                                www.solmetra.com
// ================================================
// v.2.0
// ================================================

// charset to be used in dialogs
$spaw_lang_charset = 'iso-8859-2';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'Kivбgбs'
  ),
  'copy' => array(
    'title' => 'Mбsol'
  ),
  'paste' => array(
    'title' => 'Beilleszt'
  ),
  'undo' => array(
    'title' => 'Visszavonбs'
  ),
  'redo' => array(
    'title' => 'Mйgis'
  ),
  'image_prop' => array(
    'title' => 'Kйp',
    'ok' => '   OK   ',
    'cancel' => 'Mйgsem',
    'source' => 'Forrбs',
    'alt' => 'Alternatнv szцveg',
    'align' => 'Igazнtбs',
    'left' => 'Balra',
    'right' => 'Jobbra',
    'top' => 'Fentre',
    'middle' => 'Kцzйpre',
    'bottom' => 'Lentre',
    'absmiddle' => 'Teljesen kцzйpre',
    'texttop' => 'Szцvegtetejйre',
    'baseline' => 'Alapvonalra',
    'width' => 'Szйlessйg',
    'height' => 'Magassбg',
    'border' => 'Keret',
    'hspace' => 'Vнzszintes hely',
    'vspace' => 'Fьggхleges hely',
    'dimensions' => 'Nйzetek', // <= new in 2.0.1
    'reset_dimensions' => 'Nйzetek alaphelyzetbe', // <= new in 2.0.1
    'title_attr' => 'Cнm', // <= new in 2.0.1
    'constrain_proportions' => 'Kйnyszerнtett mйretek', // <= new in 2.0.1
    'error' => 'Hiba',
    'error_width_nan' => 'Szйlessйg nem egy szбm',
    'error_height_nan' => 'Magassбg nem egy szбm',
    'error_border_nan' => 'Keret nem egy szбm',
    'error_hspace_nan' => 'Vнzszintes hely nem egy szбm',
    'error_vspace_nan' => 'Fьggхleges hely nem egy szбm',
  ),
  'flash_prop' => array(                // <= new in 2.0
    'title' => 'Flash',
    'ok' => '   OK   ',
    'cancel' => 'Mйgse',
    'source' => 'Forrбs',
    'width' => 'Szйlessйg',
    'height' => 'Magassбg',
    'error' => 'Hiba',
    'error_width_nan' => 'Szйlessйg nem egy szбm',
    'error_height_nan' => 'Magassбg nem egy szбm',
  ),
  'inserthorizontalrule' => array( // <== v.2.0 changed from hr
    'title' => 'Vнzszintes elvбlasztу'
  ),
  'table_create' => array(
    'title' => 'Tбbla kйszнtйs'
  ),
  'table_prop' => array(
    'title' => 'Tбbla tulajdonsбgok',
    'ok' => '   OK   ',
    'cancel' => 'Mйgse',
    'rows' => 'Sorok',
    'columns' => 'Oszlopok',
    'css_class' => 'CSS osztбly',
    'width' => 'Szйlessйg',
    'height' => 'Magassбg',
    'border' => 'Keret',
    'pixels' => 'Pixelek',
    'cellpadding' => 'Cella kitцltйse',
    'cellspacing' => 'Cellбk kцzцtti hely',
    'bg_color' => 'Hбttйrszнn',
    'background' => 'Hбttйrkйp',
    'error' => 'Hiba',
    'error_rows_nan' => 'Sorok nem egy szбm',
    'error_columns_nan' => 'Oszlopok nem egy szбm',
    'error_width_nan' => 'Szйlessйg nem egy szбm',
    'error_height_nan' => 'Magassбg nem egy szбm',
    'error_border_nan' => 'Keret nem egy szбm',
    'error_cellpadding_nan' => 'Cella kitцltйs nem egy szбm',
    'error_cellspacing_nan' => 'Cellбk kцzцtti hely nem egy szбm',
  ),
  'table_cell_prop' => array(
    'title' => 'Cella tulajdonsбgok',
    'horizontal_align' => 'Vнzszintes igazнtбs',
    'vertical_align' => 'Fьggхleges igazнtбs',
    'width' => 'Szйlessйg',
    'height' => 'Magassбg',
    'css_class' => 'CSS osztбly',
    'no_wrap' => 'Nincs tцrйs',
    'bg_color' => 'Hбttйrszнn',
    'background' => 'Hбttйrkйp',
    'ok' => '   OK   ',
    'cancel' => 'Mйgse',
    'left' => 'Balra',
    'center' => 'Kцzйpre',
    'right' => 'Jobbra',
    'top' => 'Fentre',
    'middle' => 'Kцzйpre',
    'bottom' => 'Lentre',
    'baseline' => 'Alapvonalra',
    'error' => 'Hiba',
    'error_width_nan' => 'Szйlessйg nem egy szбm',
    'error_height_nan' => 'Magassбg nem egy szбm',
  ),
  'table_row_insert' => array(
    'title' => 'Sor beszъrбsa'
  ),
  'table_column_insert' => array(
    'title' => 'Oszlop beszъrбsa'
  ),
  'table_row_delete' => array(
    'title' => 'Sor tцrlйse'
  ),
  'table_column_delete' => array(
    'title' => 'Oszlop tцrlйse'
  ),
  'table_cell_merge_right' => array(
    'title' => 'Cellбk egyesнtйse jobbra'
  ),
  'table_cell_merge_down' => array(
    'title' => 'Cellбk egyesнtйse lefele'
  ),
  'table_cell_split_horizontal' => array(
    'title' => 'Cellбk vнzszintes szйtszakнtбsa'
  ),
  'table_cell_split_vertical' => array(
    'title' => 'Cellбk fьggхleges szйtkaszнtбsa'
  ),
  'style' => array(
    'title' => 'Stнlus'
  ),
  'fontname' => array( // <== v.2.0 changed from font
    'title' => 'Betы'
  ),
  'fontsize' => array(
    'title' => 'Mйret'
  ),
  'formatBlock' => array( // <= v.2.0: changed from paragraph
    'title' => 'Bekezdйs'
  ),
  'bold' => array(
    'title' => 'Fйlkцvйr'
  ),
  'italic' => array(
    'title' => 'Dхlt'
  ),
  'underline' => array(
    'title' => 'Alбhъzбs'
  ),
  'strikethrough' => array(
    'title' => 'Бthъzбs'
  ),
  'insertorderedlist' => array( // <== v.2.0 changed from ordered_list
    'title' => 'Szбmozбs'
  ),
  'insertunorderedlist' => array( // <== v.2.0 changed from bulleted list
    'title' => 'Felsorolбs'
  ),
  'indent' => array(
    'title' => 'Behъzбs nцvelйse'
  ),
  'outdent' => array( // <== v.2.0 changed from unindent
    'title' => 'Behъzбs csцkkentйse'
  ),
  'justifyleft' => array( // <== v.2.0 changed from left
    'title' => 'Balra'
  ),
  'justifycenter' => array( // <== v.2.0 changed from center
    'title' => 'Kцzйpre'
  ),
  'justifyright' => array( // <== v.2.0 changed from right
    'title' => 'Jobbra'
  ),
  'justifyfull' => array( // <== v.2.0 changed from justify
    'title' => 'Sorkizбrбs'
  ),
  'fore_color' => array(
    'title' => 'Szнn'
  ),
  'bg_color' => array(
    'title' => 'Hбttйrszнn'
  ),
  'design' => array( // <== v.2.0 changed from design_tab
    'title' => 'Vбltбs a WYSWYG (design) mуdra'
  ),
  'html' => array( // <== v.2.0 changed from html_tab
    'title' => 'Vбltбs a HTML (kуd) mуdra'
  ),
  'colorpicker' => array(
    'title' => 'Szнnvбlasztу',
    'ok' => '   OK   ',
    'cancel' => 'Mйgse',
  ),
  'cleanup' => array(
    'title' => 'HTML tisztнtбs (stнlusokat megszьntet)',
    'confirm' => 'Ezzel a cselekedettel tцrli az alkalmazott stнlusokat, betыtнpusokat йs a fцlцsleges adatokat a jelen dokumentumban. Valamennyi vagy minden formбzбs el fog veszni.',
    'ok' => '   OK   ',
    'cancel' => 'Mйgse',
  ),
  'toggle_borders' => array(
    'title' => 'Szegйly megmutatбsa',
  ),
  'hyperlink' => array(
    'title' => 'Hiperhivatkozбs',
    'url' => 'Hivatkozott cнm (URL)',
    'name' => 'Nйv',
    'target' => 'Cйl',
    'title_attr' => 'Cнm',
  	'a_type' => 'Tipus',
  	'type_link' => 'Link',
  	'type_anchor' => 'Kцnyvjelzх',
  	'type_link2anchor' => 'Link a kцnyvjelzхhцz',
  	'anchors' => 'Kцnyvjelzхk',
    'ok' => '   OK   ',
    'cancel' => 'Mйgse',
  ),
  'hyperlink_targets' => array( // <=== new 1.0.5
  	'_self' => 'sajбt keret (_self)',
	'_blank' => 'ъj keret (_blank)',
	'_top' => 'legfelsх keret (_top)',
	'_parent' => 'fх keret (_parent)'
  ),
  'unlink' => array( // <=== new v.2.0
    'title' => 'Hiperhivatkozбs eltбvolнtбsa'
  ),
  'table_row_prop' => array(
    'title' => 'Sor tulajdonsбgai',
    'horizontal_align' => 'Vнzszintes igazнtбs',
    'vertical_align' => 'Fьggхeges igazнtбs',
    'css_class' => 'CSS osztбly',
    'no_wrap' => 'Nincs csomagolбs',
    'bg_color' => 'Hбttйrszнn',
    'ok' => '   OK   ',
    'cancel' => 'Mйgse',
    'left' => 'Balra',
    'center' => 'Kцzйpre',
    'right' => 'Jobbra',
    'top' => 'Tetejйre',
    'middle' => 'Kцzйpre',
    'bottom' => 'Aljбra',
    'baseline' => 'Alapvonalra',
  ),
  'symbols' => array(
    'title' => 'Speciбlis karakterek',
    'ok' => '   OK   ',
    'cancel' => 'Mйgse',
  ),
  'templates' => array(
    'title' => 'Sablonok',
  ),
  'page_prop' => array(
    'title' => 'Oldal tulajdonsбgok',
    'title_tag' => 'Cнme',
    'charset' => 'Karakter tнpus',
    'background' => 'Hбttйrkйp',
    'bgcolor' => 'Hбttйrszнn',
    'text' => 'Szцveg szнne',
    'link' => 'Hivatkozбs szнne',
    'vlink' => 'Lбtogatott hivatkozбs szнne',
    'alink' => 'Aktнv hivatkozбs szнne',
    'leftmargin' => 'Bal margу',
    'topmargin' => 'Tetх margу',
    'css_class' => 'CSS osztбly',
    'ok' => '   OK   ',
    'cancel' => 'Mйgse',
  ),
  'preview' => array(
    'title' => 'Elхnйzet',
  ),
  'image_popup' => array(
    'title' => 'Elхugrу kйp',
  ),
  'zoom' => array(
    'title' => 'Nagyнtбs',
  ),
  'subscript' => array(
    'title' => 'Alsуindex',
  ),
  'superscript' => array(
    'title' => 'Felsхindex',
  ),
);
?>
