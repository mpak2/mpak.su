<?php
// =========================================================
// SPAW PHP WYSIWYG editor control
// =========================================================
// Turkish language file
// =========================================================
// Developed: Alan Mendelevich, alan@solmetra.lt
// Turkish translation: Zeki Erkmen, zerkmen@erdoweb.com
// Copyright: Solmetra (c)2003 All rights reserved.
// ---------------------------------------------------------
//                                www.solmetra.com
// =========================================================
// 1.0.7, 2004-12-09
// =========================================================

// charset to be used in dialogs
$spaw_lang_charset = 'utf-8';

// language text data array
// first dimension - block, second - exact phrase
// alternative text for toolbar buttons and title for dropdowns - 'title'

$spaw_lang_data = array(
  'cut' => array(
    'title' => 'Kes'
  ),
  'copy' => array(
    'title' => 'Kopyala'
  ),
  'paste' => array(
    'title' => 'Ekle'
  ),
  'undo' => array(
    'title' => 'Geri al'
  ),
  'redo' => array(
    'title' => 'Tekrarla'
  ),
  'hyperlink' => array(
    'title' => 'Link ekle'
  ),
  'image_insert' => array(
    'title' => 'Resim ekle',
    'select' => 'Resmi al',
	'delete' => 'Resmi sil', // new 1.0.5
    'cancel' => 'Д°ptal',
    'library' => 'KГјtГјphane',
    'preview' => 'Г–n izle',
    'images' => 'Resim',
    'upload' => 'Resim yГјkle',
    'upload_button' => 'YГјkle',
    'error' => 'Hata',
    'error_no_image' => 'LГјtfen bir resim seГ§iniz',
    'error_uploading' => 'Resim yГјkleme iЕџleminde bir hata oluЕџtu. LГјtfen biraz sonra tekrar deneyiniz.',
    'error_wrong_type' => 'Resim tГјrГј yanlД±Еџ',
    'error_no_dir' => 'Dizinde kГјtГјphane bulunmuyor',
	'error_cant_delete' => 'Silme iЕџleminde hata oluЕџtu', // new 1.0.5
  ),
  'image_prop' => array(
    'title' => 'Resim ayarlarД±',
    'ok' => '   OK   ',
    'cancel' => 'Д°ptal',
    'source' => 'Kaynak',
    'alt' => 'Alternatif Metin',
    'align' => 'Konum',
    'justifyleft' => 'Sol',
    'justifyright' => 'SaДџ',
    'top' => 'Yukarda',
    'middle' => 'Ortada',
    'bottom' => 'Alt kД±sД±mda',
    'absmiddle' => 'Merkezde',
    'texttop' => 'Metin ГјstГј',
    'baseline' => 'Г‡izgi Гјzeri',
    'width' => 'GeniЕџlik',
    'height' => 'YГјkseklik',
    'border' => 'Г‡erceve',
    'hspace' => 'Yatay boЕџluk',
    'vspace' => 'Dikey boЕџluk',
    'error' => 'Hata',
    'error_width_nan' => 'GeniЕџlik sayД± deДџil',
    'error_height_nan' => 'YГјkseklik sayД± deДџil',
    'error_border_nan' => 'Г‡erceve sayД± deДџil',
    'error_hspace_nan' => 'Yatay boЕџluk sayД± deДџil',
    'error_vspace_nan' => 'Dikey boЕџluk sayД± deДџil',
  ),
  'inserthorizontalrule' => array(
    'title' => 'Yatay Г§izgi'
  ),
  'table_create' => array(
    'title' => 'Tabela oluЕџtur'
  ),
  'table_prop' => array(
    'title' => 'Tabela Г¶zellikleri',
    'ok' => '   OK   ',
    'cancel' => 'Д°ptal et',
    'rows' => 'SatД±rlar',
    'columns' => 'Haneler',
	'css_class' => 'CSS class', // <=== new 1.0.6
    'width' => 'GeniЕџlik',
    'height' => 'YГјkseklik',
    'border' => 'Г‡erceve',
    'pixels' => 'Pixel',
    'cellpadding' => 'HГјcreyi dolumu',
    'cellspacing' => 'HГјcre mesafesi',
    'bg_color' => 'Arka ekran rengi',
	'background' => 'Arka ekran resmi', // <=== new 1.0.6
    'error' => 'Hata',
    'error_rows_nan' => 'SatД±r rakam deДџil',
    'error_columns_nan' => 'Hane rakam deДџil',
    'error_width_nan' => 'GeniЕџlik rakam deДџil',
    'error_height_nan' => 'YГјkseklik rakam deДџil',
    'error_border_nan' => 'Г‡erceve rakam deДџil',
    'error_cellpadding_nan' => 'HГјcre dolumu rakam deДџil',
    'error_cellspacing_nan' => 'HГјcre mesafesi rakam deДџil',
  ),
  'table_cell_prop' => array(
    'title' => 'HГјcre Г¶zelliДџi',
    'horizontal_align' => 'Yatay konumu',
    'vertical_align' => 'Dikey konumu',
    'width' => 'GeniЕџlik',
    'height' => 'YГјkseklik',
    'css_class' => 'CSS sД±nД±fД±',
    'no_wrap' => 'Paketsiz',
    'bg_color' => 'Arka ekran rengi',
	'background' => 'Arka ekran resmi', // <=== new 1.0.6
    'ok' => '   OK   ',
    'cancel' => 'Д°ptal et',
    'justifyleft' => 'Sol',
    'justifycenter' => 'Merkezi',
    'justifyright' => 'SaДџ',
    'top' => 'Гњst kД±sД±m',
    'middle' => 'Orta',
    'bottom' => 'Alt kД±sД±m',
    'baseline' => 'Г‡izgi ГјstГј',
    'error' => 'Hata',
    'error_width_nan' => 'GeniЕџlik rakam deДџil',
    'error_height_nan' => 'YГјkseklik rakam deДџil',
    
  ),
  'table_row_insert' => array(
    'title' => 'SatД±r ekle'
  ),
  'table_column_insert' => array(
    'title' => 'Hane ekle'
  ),
  'table_row_delete' => array(
    'title' => 'SatД±r sil'
  ),
  'table_column_delete' => array(
    'title' => 'Hane sil'
  ),
  'table_cell_merge_right' => array(
    'title' => 'HГјcreyi saДџ taraf ile birleЕџtir.'
  ),
  'table_cell_merge_down' => array(
    'title' => 'HГјcereyi alt taraf ile birleЕџtir.'
  ),
  'table_cell_split_horizontal' => array(
    'title' => 'HГјcreyi yatay olarak bГ¶l'
  ),
  'table_cell_split_vertical' => array(
    'title' => 'HГјcreyi dikey olarak bГ¶l'
  ),
  'style' => array(
    'title' => 'DГјzenleme'
  ),
  'fontname' => array(
    'title' => 'YazД±'
  ),
  'fontsize' => array(
    'title' => 'BГјyГјklГјДџГј'
  ),
  'formatBlock' => array(
    'title' => 'ParaДџraf'
  ),
  'bold' => array(
    'title' => 'KalД±n'
  ),
  'italic' => array(
    'title' => 'Yatay ince'
  ),
  'underline' => array(
    'title' => 'Alt Г§izgili'
  ),
  'insertorderedlist' => array(
    'title' => 'Numarasal'
  ),
  'insertunorderedlist' => array(
    'title' => 'Listesel'
  ),
  'indent' => array(
    'title' => 'DД±Еџa Г§ek'
  ),
  'outdent' => array(
    'title' => 'Д°Г§e Г§ek'
  ),
  'justifyleft' => array(
    'title' => 'Sol'
  ),
  'justifycenter' => array(
    'title' => 'Merkez'
  ),
  'justifyright' => array(
    'title' => 'SaДџ'
  ),
  'fore_color' => array(
    'title' => 'YazД± rengi'
  ),
  'bg_color' => array(
    'title' => 'Arka ekran rengi'
  ),
  'design' => array(
    'title' => 'Design ModГјsГјne geГ§'
  ),
  'html' => array(
    'title' => 'HTML ModГјsГјne geГ§'
  ),
  'colorpicker' => array(
    'title' => 'Renk seГ§imi',
    'ok' => '   OK   ',
    'cancel' => 'Д°ptal et',
  ),
  'cleanup' => array(
    'title' => 'HTML temizleyeГ§i',
    'confirm' => 'Bu seГ§enek HTML formatlarД±nД± (Style) Д°Г§eriДџinizden siler. Bu komutu seГ§mekle ya tГјm ya da bazД± Style blocklarД± metin iГ§erisinden silinir ',
    'ok' => '   OK   ',
    'cancel' => 'Д°ptal',
  ),
  'toggle_borders' => array(
    'title' => 'Toggle borders',
  ),
  'hyperlink' => array(
    'title' => 'Link ekle',
    'url' => 'URL',
    'name' => 'AdД±',
    'target' => 'Hedef',
    'title_attr' => 'BaЕџlД±k',
	'a_type' => 'Tip', // <=== new 1.0.6
	'type_link' => 'Link', // <=== new 1.0.6
	'type_anchor' => 'Г‡apa', // <=== new 1.0.6
	'type_link2anchor' => 'Г‡apaya link', // <=== new 1.0.6
	'anchors' => 'Anchors', // <=== new 1.0.6
    'ok' => '   OK   ',
    'cancel' => 'Д°ptal',
  ),
  'hyperlink_targets' => array( // <=== new 1.0.5
  	'_self' => 'kendi penceresi (_self)',
	'_blank' => 'boЕџ yeni pencerede (_blank)',
	'_top' => 'bir Гјst pencerede (_top)',
	'_parent' => 'aynД± pencerede (_parent)'
  ),
  'table_row_prop' => array(
    'title' => 'SatД±r Г¶zellikleri',
    'horizontal_align' => 'Yatay konum',
    'vertical_align' => 'Dikey konum',
    'css_class' => 'CSS KlasД±',
    'no_wrap' => 'Paketsiz',
    'bg_color' => 'Arka ekran rengi',
    'ok' => '   OK   ',
    'cancel' => 'Д°ptal',
    'justifyleft' => 'Sol',
    'justifycenter' => 'Merkez',
    'justifyright' => 'SaДџ',
    'top' => 'Гњst',
    'middle' => 'Orta',
    'bottom' => 'Alt',
    'baseline' => 'Г‡izgi ГјstГј',
  ),
  'symbols' => array(
    'title' => 'Г–zel karekterler',
    'ok' => '   OK   ',
    'cancel' => 'Д°ptal',
  ),
  'templates' => array(
    'title' => 'KalД±plar',
  ),
  'page_prop' => array(
    'title' => 'Sayfa Г¶zelliДџi',
    'title_tag' => 'BaЕџlД±k',
    'charset' => 'Metin Karekteri',
    'background' => 'Arka plan resmi',
    'bgcolor' => 'Arka plan rengi',
    'text' => 'YazД± rengi',
    'link' => 'Link rengi',
    'vlink' => 'UДџranД±lmД±Еџ link rengi',
    'alink' => 'Actif link rengi',
    'leftmargin' => 'Sol kenar',
    'topmargin' => 'Гњst kenar',
    'css_class' => 'CSS KlasД±',
    'ok' => '   OK   ',
    'cancel' => 'Д°ptal',
  ),
  'preview' => array(
    'title' => 'Г–n gГ¶sterim',
  ),
  'image_popup' => array(
    'title' => 'Resim popup',
  ),
  'zoom' => array(
    'title' => 'BГјyГјlteГ§',
  ),
  'subscript' => array( // <=== new 1.0.7
    'title' => 'Subscript',
  ),
  'superscript' => array( // <=== new 1.0.7
    'title' => 'Superscript',
  ),
);
?>